function buscarEstudiante() {
    const id = document.getElementById("inputID").value;
    fetch("/api/estudiante?id=" + id)
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                document.getElementById("infoEstudiante").innerHTML = "<p>No se encontró estudiante.</p>";
                document.getElementById("registroAtencion").style.display = "none";
            } else {
                document.getElementById("infoEstudiante").innerHTML = `
                    <p><strong>Nombre:</strong> ${data.nombre}</p>
                    <p><strong>Programa:</strong> ${data.programa}</p>
                    <p><strong>Estado:</strong> ${data.estado}</p>
                `;
                document.getElementById("registroAtencion").style.display = "block";
                document.getElementById("registroAtencion").setAttribute("data-id", id);
            }
        });
}

function registrarAtencion() {
    const id = document.getElementById("registroAtencion").getAttribute("data-id");
    const descripcion = document.getElementById("descripcion").value;

    fetch("/api/atencion", {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ id: id, descripcion: descripcion })
    }).then(res => {
        if (res.ok) {
            alert("Atención registrada correctamente.");
            document.getElementById("descripcion").value = "";
        } else {
            alert("Error al registrar atención.");
        }
    });
}

function consultarAtenciones() {
    const id = document.getElementById("inputID").value;

    fetch("/api/atenciones?id=" + id)
        .then(res => res.json())
        .then(data => {
            const lista = document.getElementById("listaAtenciones");
            lista.innerHTML = "";
            if (data.length === 0) {
                lista.innerHTML = "<li>No hay atenciones registradas.</li>";
            } else {
                data.forEach(item => {
                    const li = document.createElement("li");
                    li.textContent = item.fecha + ": " + item.descripcion;
                    lista.appendChild(li);
                });
            }
        });
}
