import { NextResponse, type NextRequest } from "next/server"

const publicPaths = ["/login", "/api/auth/login"] // Rutas que no requieren token
const apiAuthPaths = ["/api/auth/logout", "/api/auth/me"] // Rutas API de auth que necesitan token pero se manejan diferente

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl
  const sessionToken = request.cookies.get("session_token")?.value

  // Permitir acceso a rutas públicas
  if (publicPaths.some((path) => pathname.startsWith(path))) {
    return NextResponse.next()
  }

  // Si no hay token y la ruta no es pública ni una API de auth que lo requiera, redirigir a login
  if (!sessionToken && !apiAuthPaths.some((path) => pathname.startsWith(path))) {
    const loginUrl = new URL("/login", request.url)
    loginUrl.searchParams.set("origen", pathname) // Guardar la ruta original para redirigir después
    return NextResponse.redirect(loginUrl)
  }

  // Si hay token o es una API de auth que lo requiere, permitir el acceso.
  // La lógica de roles y validez del token se maneja en el cliente (AuthProvider) y en /api/auth/me
  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - ae-upn-logo.png
     * - logo-apoyo-estudiantil-upn.png
     * - logo_SI.png
     * - Logo_UPN.jpeg
     */
    "/((?!_next/static|_next/image|favicon.ico|ae-upn-logo.png|logo-apoyo-estudiantil-upn.png|logo_SI.png|Logo_UPN.jpeg).*)",
  ],
}
