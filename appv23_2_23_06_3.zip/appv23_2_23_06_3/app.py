from flask import Flask, request, jsonify, render_template
import sqlite3
from datetime import datetime

app = Flask(__name__)
DB = 'data/seguimiento.db'

@app.route('/')
def index():
    return render_template('inicio.html')

@app.route('/consultar')
def consultar_vista():
    return render_template('registrar.html')

@app.route('/registrar')
def registrar_vista():
    return render_template('registrar.html')

@app.route('/exportar')
def exportar():
    return render_template('exportar.html')

@app.route('/api/estudiante')
def get_estudiante():
    estudiante_id = request.args.get('id')
    conn = sqlite3.connect(DB)
    cursor = conn.cursor()
    cursor.execute("SELECT nombre, programa, estado FROM estudiantes WHERE id = ?", (estudiante_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return jsonify({"nombre": row[0], "programa": row[1], "estado": row[2]})
    else:
        return jsonify({"error": "No encontrado"}), 404

@app.route('/api/atencion', methods=['POST'])
def registrar_atencion():
    data = request.get_json()
    conn = sqlite3.connect(DB)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO atenciones (estudiante_id, fecha, descripcion) VALUES (?, ?, ?)",
                   (data['id'], datetime.now().isoformat(), data['descripcion']))
    conn.commit()
    conn.close()
    return '', 200

@app.route('/api/atenciones')
def consultar_atenciones():
    estudiante_id = request.args.get('id')
    conn = sqlite3.connect(DB)
    cursor = conn.cursor()
    cursor.execute("SELECT fecha, descripcion FROM atenciones WHERE estudiante_id = ? ORDER BY fecha DESC", (estudiante_id,))
    rows = cursor.fetchall()
    conn.close()
    return jsonify([{"fecha": row[0], "descripcion": row[1]} for row in rows])

if __name__ == '__main__':
    app.run(debug=True)
