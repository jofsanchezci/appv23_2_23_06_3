-- Borrar tablas existentes en el orden correcto para evitar errores de FK
DROP TABLE IF EXISTS atenciones;
DROP TABLE IF EXISTS usuarios_sistema;
DROP TABLE IF EXISTS estudiantes;

-- Crear extensiones necesarias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabla de estudiantes con una única columna 'nombre'
CREATE TABLE IF NOT EXISTS estudiantes (
    id VARCHAR(20) PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    programa VARCHAR(255) NOT NULL,
    estado VARCHAR(50) NOT NULL DEFAULT 'Activo',
    semestre VARCHAR(10),
    email VARCHAR(255),
    telefono VARCHAR(20),
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de atenciones con todas las columnas necesarias y nulleables
CREATE TABLE IF NOT EXISTS atenciones (
    id SERIAL PRIMARY KEY,
    estudiante_id VARCHAR(20) NOT NULL,
    fecha_atencion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    tipo_atencion VARCHAR(100) DEFAULT 'General',
    descripcion TEXT NOT NULL,
    observaciones TEXT, -- Columna para observaciones adicionales
    remision_area VARCHAR(255), -- Área a la que se remite
    remision_motivo TEXT, -- Motivo de la remisión
    remision_urgencia VARCHAR(50), -- Nivel de urgencia (baja, media, alta)
    remision_seguimiento BOOLEAN, -- Si requiere seguimiento
    remision_fecha_limite DATE, -- Fecha límite para el seguimiento de la remisión
    FOREIGN KEY (estudiante_id) REFERENCES estudiantes (id) ON DELETE CASCADE
);

-- Índices para optimizar consultas
CREATE INDEX IF NOT EXISTS idx_estudiantes_nombre ON estudiantes(nombre);
CREATE INDEX IF NOT EXISTS idx_atenciones_estudiante ON atenciones(estudiante_id);
CREATE INDEX IF NOT EXISTS idx_atenciones_fecha ON atenciones(fecha_atencion);
