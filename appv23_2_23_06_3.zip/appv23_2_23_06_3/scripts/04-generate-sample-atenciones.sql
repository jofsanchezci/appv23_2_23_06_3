-- Generar atenciones de ejemplo basadas en los estados académicos de los estudiantes
INSERT INTO atenciones (estudiante_id, descripcion, tipo_atencion, fecha) VALUES
-- Estudiantes con alertas académicas
('1000730234', 'Seguimiento por alerta académica - promedio bajo en semestre 2024-2', 'Académica', '2024-11-15'),
('1000730234', 'Asesoría para mejoramiento académico y estrategias de estudio', 'Académica', '2024-12-01'),
('1000005185', 'Consulta sobre alerta académica por promedio ponderado', 'Académica', '2024-11-20'),
('79647702', 'Seguimiento por alerta académica alta - plan de mejoramiento', 'Académica', '2024-12-05'),
('1022345838', 'Asesoría académica por bajo rendimiento en materias', 'Académica', '2024-11-25'),
('1096948124', 'Consulta sobre estrategias para superar alerta académica', 'Académica', '2024-12-10'),
('52796510', 'Seguimiento académico por alerta alta', 'Académica', '2024-11-30'),

-- Estudiantes próximos a graduarse
('52697720', 'Orientación sobre proceso de grado - terminación de materias', 'Administrativa', '2024-12-01'),
('51641555', 'Consulta sobre requisitos para inscripción a grado', 'Administrativa', '2024-12-05'),
('1018431392', 'Asesoría para inscripción a grado', 'Administrativa', '2024-12-08'),
('1023924732', 'Orientación sobre proceso de grado', 'Administrativa', '2024-12-10'),
('1023975926', 'Consulta sobre inscripción a grado', 'Administrativa', '2024-12-12'),
('1032442597', 'Seguimiento proceso de terminación de materias', 'Administrativa', '2024-12-15'),
('52980486', 'Orientación para inscripción a grado', 'Administrativa', '2024-12-18'),
('1054226834', 'Consulta sobre requisitos de grado', 'Administrativa', '2024-12-20'),

-- Estudiantes activos - consultas generales
('1022384479', 'Consulta sobre horarios para semestre 2025-1', 'Académica', '2025-01-10'),
('1012323545', 'Asesoría para selección de materias electivas', 'Académica', '2025-01-12'),
('1032506467', 'Orientación sobre intercambio estudiantil', 'Académica', '2025-01-15'),
('1003690160', 'Consulta sobre prácticas profesionales', 'Profesional', '2025-01-18'),
('1000004457', 'Asesoría académica para proyecto de grado', 'Académica', '2025-01-20'),
('1028780613', 'Consulta sobre programas de especialización', 'Profesional', '2025-01-22'),
('66966609', 'Orientación vocacional y cambio de énfasis', 'Académica', '2024-12-28'),
('1005239698', 'Consulta sobre becas y ayudas financieras', 'Financiera', '2025-01-05'),

-- Casos especiales
('52269833', 'Verificación de proceso académico y estado actual', 'Administrativa', '2024-12-20'),
('1000494871', 'Consulta sobre reincorporación académica', 'Administrativa', '2024-11-10'),
('1015393782', 'Orientación sobre alternativas académicas', 'Académica', '2024-10-15'),
('52286921', 'Consulta sobre reactivación de matrícula', 'Administrativa', '2024-09-20'),

-- Seguimientos regulares
('1022384479', 'Seguimiento académico regular - buen rendimiento', 'Académica', '2024-11-01'),
('1012323545', 'Consulta sobre oportunidades de investigación', 'Académica', '2024-11-15'),
('1032506467', 'Asesoría para participación en concursos estudiantiles', 'Académica', '2024-12-01'),
('1000730234', 'Seguimiento post-asesoría académica', 'Académica', '2025-01-08'),
('1000005185', 'Evaluación de progreso académico', 'Académica', '2025-01-10'),

-- Consultas administrativas
('52470248', 'Solicitud de certificados académicos', 'Administrativa', '2024-12-05'),
('53003066', 'Consulta sobre convalidación de materias', 'Administrativa', '2024-12-08'),
('36753164', 'Verificación de créditos académicos', 'Administrativa', '2024-12-12'),
('1022972690', 'Consulta sobre cambio de programa', 'Administrativa', '2024-12-15');
