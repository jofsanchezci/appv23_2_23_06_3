-- Crear tabla de estudiantes
CREATE TABLE IF NOT EXISTS estudiantes (
    id TEXT PRIMARY KEY,
    nombre TEXT NOT NULL,
    programa TEXT NOT NULL,
    estado TEXT NOT NULL DEFAULT 'Activo',
    semestre TEXT,
    email TEXT,
    telefono TEXT,
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Crear tabla de atenciones
CREATE TABLE IF NOT EXISTS atenciones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    estudiante_id TEXT NOT NULL,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    descripcion TEXT NOT NULL,
    tipo_atencion TEXT DEFAULT 'General',
    FOREIGN KEY (estudiante_id) REFERENCES estudiantes (id)
);

-- Insertar datos de ejemplo
INSERT OR REPLACE INTO estudiantes (id, nombre, programa, estado, semestre, email, telefono) VALUES
('12345', 'Juan Carlos Pérez', 'Ingeniería de Sistemas', 'Activo', '8vo', 'juan.perez@upn.edu.pe', '+51 987 654 321'),
('67890', 'María Elena García', 'Administración de Empresas', 'Activo', '6to', 'maria.garcia@upn.edu.pe', '+51 987 123 456'),
('11111', 'Carlos Rodriguez', 'Contabilidad', 'Activo', '4to', 'carlos.rodriguez@upn.edu.pe', '+51 987 111 222'),
('22222', 'Ana Lucia Torres', 'Marketing', 'Activo', '7mo', 'ana.torres@upn.edu.pe', '+51 987 333 444'),
('33333', 'Pedro Gonzales', 'Psicología', 'Inactivo', '2do', 'pedro.gonzales@upn.edu.pe', '+51 987 555 666');

-- Insertar atenciones de ejemplo
INSERT OR REPLACE INTO atenciones (estudiante_id, descripcion, tipo_atencion) VALUES
('12345', 'Consulta sobre horarios de clases del próximo semestre', 'Académica'),
('12345', 'Asesoría académica para selección de cursos electivos', 'Académica'),
('67890', 'Orientación sobre prácticas profesionales y empresas disponibles', 'Profesional'),
('67890', 'Seguimiento de proceso de titulación', 'Administrativa'),
('11111', 'Consulta sobre becas y ayudas económicas', 'Financiera');
