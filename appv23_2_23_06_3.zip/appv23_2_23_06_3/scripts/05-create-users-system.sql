-- Crear tabla de usuarios del sistema
CREATE TABLE IF NOT EXISTS usuarios_sistema (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    nombre_completo VARCHAR(200) NOT NULL,
    rol VARCHAR(20) NOT NULL CHECK (rol IN ('administrador', 'consulta', 'registro')),
    activo BOOLEAN DEFAULT true,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ultimo_acceso TIMESTAMP,
    creado_por INTEGER REFERENCES usuarios_sistema(id)
);

-- Crear tabla de sesiones
CREATE TABLE IF NOT EXISTS sesiones_usuario (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER REFERENCES usuarios_sistema(id) ON DELETE CASCADE,
    token_sesion VARCHAR(255) UNIQUE NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_expiracion TIMESTAMP NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    activa BOOLEAN DEFAULT true
);

-- Crear tabla de logs de actividad
CREATE TABLE IF NOT EXISTS logs_actividad (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER REFERENCES usuarios_sistema(id),
    accion VARCHAR(100) NOT NULL,
    modulo VARCHAR(50) NOT NULL,
    detalles JSONB,
    ip_address VARCHAR(45),
    fecha_accion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insertar usuarios por defecto
INSERT INTO usuarios_sistema (username, email, password_hash, nombre_completo, rol) VALUES
-- Contraseña: admin123
('admin', 'ccruebab@upn.edu.co', '$2b$10$rOzJqQqQqQqQqQqQqQqQqOzJqQqQqQqQqQqQqQqQqQqQqQqQqQqQqQ', 'Administrador del Sistema', 'administrador'),
-- Contraseña: consulta123
('consulta', 'consulta@upn.edu.co', '$2b$10$cOzJqQqQqQqQqQqQqQqQqOzJqQqQqQqQqQqQqQqQqQqQqQqQqQqQqQ', 'Usuario de Consulta', 'consulta'),
-- Contraseña: registro123
('registro', 'registro@upn.edu.co', '$2b$10$rOzJqQqQqQqQqQqQqQqQqOzJqQqQqQqQqQqQqQqQqQqQqQqQqQqQqQ', 'Usuario de Registro', 'registro');

-- Crear índices para optimizar consultas
CREATE INDEX IF NOT EXISTS idx_usuarios_username ON usuarios_sistema(username);
CREATE INDEX IF NOT EXISTS idx_usuarios_email ON usuarios_sistema(email);
CREATE INDEX IF NOT EXISTS idx_usuarios_rol ON usuarios_sistema(rol);
CREATE INDEX IF NOT EXISTS idx_sesiones_token ON sesiones_usuario(token_sesion);
CREATE INDEX IF NOT EXISTS idx_sesiones_usuario ON sesiones_usuario(usuario_id);
CREATE INDEX IF NOT EXISTS idx_logs_usuario ON logs_actividad(usuario_id);
CREATE INDEX IF NOT EXISTS idx_logs_fecha ON logs_actividad(fecha_accion);
