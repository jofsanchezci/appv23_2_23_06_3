-- Insertar datos de ejemplo de estudiantes
INSERT INTO estudiantes (id, nombre, programa, estado, semestre, email, telefono) VALUES
('12345', 'Juan Carlos Pérez', 'Ingeniería de Sistemas', 'Activo', '8vo', 'juan.perez@upn.edu.pe', '+51 987 654 321'),
('67890', 'María Elena García', 'Administración de Empresas', 'Activo', '6to', 'maria.garcia@upn.edu.pe', '+51 987 123 456'),
('11111', 'Carlos Rodriguez', 'Contabilidad', 'Activo', '4to', 'carlos.rodriguez@upn.edu.pe', '+51 987 111 222'),
('22222', 'Ana Lucia Torres', 'Marketing', 'Activo', '7mo', 'ana.torres@upn.edu.pe', '+51 987 333 444'),
('33333', 'Pedro Gonzales', 'Psicología', 'Inactivo', '2do', 'pedro.gonzales@upn.edu.pe', '+51 987 555 666'),
('44444', 'Sofia Mendoza', 'Derecho', 'Activo', '5to', 'sofia.mendoza@upn.edu.pe', '+51 987 777 888'),
('55555', 'Diego Ramirez', 'Arquitectura', 'Activo', '9no', 'diego.ramirez@upn.edu.pe', '+51 987 999 000'),
('66666', 'Valentina Cruz', 'Medicina', 'Activo', '3ro', 'valentina.cruz@upn.edu.pe', '+51 987 222 333')
ON CONFLICT (id) DO NOTHING;

-- Insertar atenciones de ejemplo
INSERT INTO atenciones (estudiante_id, descripcion, tipo_atencion) VALUES
('12345', 'Consulta sobre horarios de clases del próximo semestre', 'Académica'),
('12345', 'Asesoría académica para selección de cursos electivos', 'Académica'),
('12345', 'Solicitud de certificado de estudios', 'Administrativa'),
('67890', 'Orientación sobre prácticas profesionales y empresas disponibles', 'Profesional'),
('67890', 'Seguimiento de proceso de titulación', 'Administrativa'),
('67890', 'Consulta sobre intercambio estudiantil', 'Académica'),
('11111', 'Consulta sobre becas y ayudas económicas', 'Financiera'),
('11111', 'Asesoría para proyecto de tesis', 'Académica'),
('22222', 'Orientación vocacional y cambio de carrera', 'Académica'),
('22222', 'Consulta sobre programas de especialización', 'Profesional'),
('33333', 'Proceso de reincorporación académica', 'Administrativa'),
('44444', 'Consulta sobre prácticas pre-profesionales', 'Profesional'),
('55555', 'Asesoría para concurso de proyectos estudiantiles', 'Académica'),
('66666', 'Orientación sobre rotaciones clínicas', 'Profesional');
