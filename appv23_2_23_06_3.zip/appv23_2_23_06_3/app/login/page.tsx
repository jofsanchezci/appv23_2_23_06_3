"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Image from "next/image"
import { AlertCircle, LogIn } from "lucide-react"
import { useRouter, useSearchParams } from "next/navigation"

export default function LoginPage() {
  const { login, loading: authLoading } = useAuth()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsSubmitting(true)
    const success = await login(username, password)
    if (!success) {
      setError("Credenciales incorrectas. Intente de nuevo.")
    } else {
      const origen = searchParams.get("origen")
      if (origen && origen !== "/login") {
        router.push(origen)
      }
      // El AuthProvider se encargará de redirigir al dashboard por rol si no hay origen
    }
    setIsSubmitting(false)
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-red-900 p-4">
      <Card className="w-full max-w-md shadow-2xl bg-white/90 backdrop-blur-sm">
        <CardHeader className="text-center">
          <Image
            src="/logo-apoyo-estudiantil-upn.png" // Asegúrate que este logo exista en public
            alt="Logo Apoyo Estudiantil UPN"
            width={120}
            height={120}
            className="mx-auto mb-4 rounded-full"
          />
          <CardTitle className="text-3xl font-bold text-slate-800">Bienvenido</CardTitle>
          <CardDescription className="text-slate-600">Sistema de Seguimiento Estudiantil - UPN</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-slate-700">
                Usuario
              </Label>
              <Input
                id="username"
                type="text"
                placeholder="nombre.usuario"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                className="bg-white/80 focus:bg-white"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-slate-700">
                Contraseña
              </Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="bg-white/80 focus:bg-white"
              />
            </div>
            {error && (
              <div className="flex items-center text-sm text-red-600 bg-red-50 p-3 rounded-md">
                <AlertCircle className="h-4 w-4 mr-2" />
                {error}
              </div>
            )}
            <Button
              type="submit"
              className="w-full bg-red-700 hover:bg-red-800 text-white"
              disabled={isSubmitting || authLoading}
            >
              {isSubmitting || authLoading ? (
                "Ingresando..."
              ) : (
                <>
                  {" "}
                  <LogIn className="mr-2 h-4 w-4" /> Ingresar{" "}
                </>
              )}
            </Button>
          </form>
          <div className="mt-6 text-center text-xs text-slate-500">
            <p>&copy; {new Date().getFullYear()} Universidad Pedagógica Nacional</p>
            <p className="mt-2">Usuarios de prueba:</p>
            <ul className="list-disc list-inside">
              <li>admin / adminpassword</li>
              <li>consulta / consultapassword</li>
              <li>registro / registropassword</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
