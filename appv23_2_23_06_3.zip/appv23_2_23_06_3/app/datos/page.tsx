"use client"

import type React from "react"

import { useState } from "react"
import { NavigationHeader } from "@/components/navigation-header"
import { ProtectedRoute } from "@/components/protected-route"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Upload, DatabaseZap, FileSpreadsheet, AlertTriangle, CheckCircle, Users } from "lucide-react"
import { useToast } from "@/hooks/use-toast" // Asumiendo que tienes este hook de shadcn/ui

export default function DatosPage() {
  const { toast } = useToast()
  const [estudiantesFile, setEstudiantesFile] = useState<File | null>(null)
  const [atencionesFile, setAtencionesFile] = useState<File | null>(null)
  const [isUploadingEstudiantes, setIsUploadingEstudiantes] = useState(false)
  const [isUploadingAtenciones, setIsUploadingAtenciones] = useState(false)
  const [uploadStatus, setUploadStatus] = useState<{ type: "success" | "error"; message: string } | null>(null)

  const handleFileChange = (
    event: React.ChangeEvent<HTMLInputElement>,
    setter: React.Dispatch<React.SetStateAction<File | null>>,
  ) => {
    if (event.target.files && event.target.files[0]) {
      setter(event.target.files[0])
      setUploadStatus(null) // Reset status on new file selection
    }
  }

  const handleUpload = async (fileType: "estudiantes" | "atenciones") => {
    const file = fileType === "estudiantes" ? estudiantesFile : atencionesFile
    const setIsUploading = fileType === "estudiantes" ? setIsUploadingEstudiantes : setIsUploadingAtenciones

    if (!file) {
      setUploadStatus({ type: "error", message: `Por favor, selecciona un archivo de ${fileType}.` })
      toast({
        title: "Error",
        description: `Por favor, selecciona un archivo de ${fileType}.`,
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)
    setUploadStatus(null)

    // Simulación de carga
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Simulación de respuesta
    const success = Math.random() > 0.3 // 70% de éxito simulado
    if (success) {
      setUploadStatus({ type: "success", message: `Archivo de ${fileType} (${file.name}) cargado exitosamente.` })
      toast({
        title: "Carga Exitosa",
        description: `Archivo de ${fileType} (${file.name}) procesado.`,
      })
      if (fileType === "estudiantes") setEstudiantesFile(null)
      else setAtencionesFile(null)
    } else {
      setUploadStatus({
        type: "error",
        message: `Error al cargar el archivo de ${fileType} (${file.name}). Intenta de nuevo.`,
      })
      toast({
        title: "Error de Carga",
        description: `No se pudo procesar el archivo de ${fileType}.`,
        variant: "destructive",
      })
    }
    setIsUploading(false)
  }

  return (
    <ProtectedRoute allowedRoles={["administrador"]} permission="gestionar_datos">
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-slate-900 dark:via-slate-800 dark:to-blue-900">
        <NavigationHeader />
        <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="shadow-xl dark:bg-slate-800">
            <CardHeader>
              <CardTitle className="flex items-center text-2xl font-bold text-slate-800 dark:text-slate-100">
                <DatabaseZap className="h-7 w-7 mr-3 text-blue-600" />
                Gestión de Datos Masivos
              </CardTitle>
              <CardDescription className="dark:text-slate-400">
                Carga y actualiza datos de estudiantes y atenciones mediante archivos CSV o Excel.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              {uploadStatus && (
                <div
                  className={`p-4 rounded-md flex items-center text-sm ${
                    uploadStatus.type === "success"
                      ? "bg-green-50 dark:bg-green-900/30 text-green-700 dark:text-green-300 border border-green-200 dark:border-green-700"
                      : "bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-700"
                  }`}
                >
                  {uploadStatus.type === "success" ? (
                    <CheckCircle className="h-5 w-5 mr-2" />
                  ) : (
                    <AlertTriangle className="h-5 w-5 mr-2" />
                  )}
                  {uploadStatus.message}
                </div>
              )}

              {/* Carga de Estudiantes */}
              <div className="space-y-3 p-6 border rounded-lg dark:border-slate-700 bg-slate-50 dark:bg-slate-700/30">
                <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-200 flex items-center">
                  <Users className="h-5 w-5 mr-2 text-blue-500" />
                  Cargar Datos de Estudiantes
                </h3>
                <div className="grid w-full max-w-sm items-center gap-1.5">
                  <Label htmlFor="estudiantesFile" className="dark:text-slate-300">
                    Archivo (CSV, Excel)
                  </Label>
                  <Input
                    id="estudiantesFile"
                    type="file"
                    accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
                    onChange={(e) => handleFileChange(e, setEstudiantesFile)}
                    className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-300 file:text-blue-600 file:dark:text-blue-400"
                  />
                  {estudiantesFile && (
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Archivo seleccionado: {estudiantesFile.name}
                    </p>
                  )}
                </div>
                <Button
                  onClick={() => handleUpload("estudiantes")}
                  disabled={isUploadingEstudiantes || !estudiantesFile}
                  className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  {isUploadingEstudiantes ? "Cargando Estudiantes..." : "Cargar Estudiantes"}
                </Button>
              </div>

              {/* Carga de Atenciones */}
              <div className="space-y-3 p-6 border rounded-lg dark:border-slate-700 bg-slate-50 dark:bg-slate-700/30">
                <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-200 flex items-center">
                  <FileSpreadsheet className="h-5 w-5 mr-2 text-green-500" />
                  Cargar Historial de Atenciones
                </h3>
                <div className="grid w-full max-w-sm items-center gap-1.5">
                  <Label htmlFor="atencionesFile" className="dark:text-slate-300">
                    Archivo (CSV, Excel)
                  </Label>
                  <Input
                    id="atencionesFile"
                    type="file"
                    accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
                    onChange={(e) => handleFileChange(e, setAtencionesFile)}
                    className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-300 file:text-green-600 file:dark:text-green-400"
                  />
                  {atencionesFile && (
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Archivo seleccionado: {atencionesFile.name}
                    </p>
                  )}
                </div>
                <Button
                  onClick={() => handleUpload("atenciones")}
                  disabled={isUploadingAtenciones || !atencionesFile}
                  className="w-full sm:w-auto bg-green-600 hover:bg-green-700 text-white"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  {isUploadingAtenciones ? "Cargando Atenciones..." : "Cargar Atenciones"}
                </Button>
              </div>

              <div className="pt-6 border-t dark:border-slate-700">
                <h4 className="text-md font-semibold text-slate-700 dark:text-slate-200 mb-2">
                  Instrucciones y Formato
                </h4>
                <ul className="list-disc list-inside text-sm text-slate-600 dark:text-slate-400 space-y-1">
                  <li>Asegúrate de que los archivos estén en formato CSV o Excel (XLSX).</li>
                  <li>La primera fila del archivo debe contener los encabezados de las columnas.</li>
                  <li>
                    Para estudiantes: columnas esperadas (ej: ID, NombreCompleto, Programa, Email, Telefono, Estado,
                    Semestre).
                  </li>
                  <li>
                    Para atenciones: columnas esperadas (ej: ID_Estudiante, FechaAtencion, TipoAtencion, Descripcion,
                    AreaRemision, MotivoRemision).
                  </li>
                  <li>Los datos existentes podrían actualizarse si se encuentran coincidencias por ID.</li>
                </ul>
                <Button variant="link" className="mt-2 p-0 h-auto text-blue-600 dark:text-blue-400">
                  Descargar Plantillas de Ejemplo (Próx.)
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </ProtectedRoute>
  )
}
