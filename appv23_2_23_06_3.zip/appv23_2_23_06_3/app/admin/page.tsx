"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { NavigationHeader } from "@/components/navigation-header"
import { ProtectedRoute } from "@/components/protected-route"
import {
  Users,
  FileText,
  BarChart3,
  Shield,
  Activity,
  UserPlus,
  Download,
  Eye,
  Settings,
  AlertTriangle,
  Database,
} from "lucide-react"
import Link from "next/link"
import { useAuth } from "@/components/auth-provider"

export default function AdminPage() {
  const { verificarPermiso } = useAuth()
  const [estadisticas, setEstadisticas] = useState({
    totalUsuarios: 3, // admin, registro, consulta
    totalEstudiantes: 49, // Simulado
    atencionesHoy: 5, // Simulado
    remisionesActivas: 8, // Simulado
  })

  // Simulación de carga de datos o actualización
  useEffect(() => {
    // Aquí podrías llamar a una API para obtener datos reales
  }, [])

  return (
    <ProtectedRoute allowedRoles={["administrador"]} permission="ver_admin">
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-sky-50 dark:from-slate-900 dark:via-slate-800 dark:to-sky-900">
        <NavigationHeader />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-2">Panel de Administración</h1>
            <p className="text-slate-600 dark:text-slate-400">
              Gestión integral del Sistema de Seguimiento Estudiantil.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <Card className="bg-gradient-to-r from-sky-500 to-sky-600 text-white dark:from-sky-600 dark:to-sky-700">
              <CardContent className="p-6 flex items-center justify-between">
                <div>
                  <p className="text-sky-100">Usuarios del Sistema</p>
                  <p className="text-3xl font-bold">{estadisticas.totalUsuarios}</p>
                </div>
                <Users className="h-12 w-12 text-sky-200" />
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white dark:from-emerald-600 dark:to-emerald-700">
              <CardContent className="p-6 flex items-center justify-between">
                <div>
                  <p className="text-emerald-100">Estudiantes Registrados</p>
                  <p className="text-3xl font-bold">{estadisticas.totalEstudiantes}</p>
                </div>
                <UserPlus className="h-12 w-12 text-emerald-200" />
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white dark:from-purple-600 dark:to-purple-700">
              <CardContent className="p-6 flex items-center justify-between">
                <div>
                  <p className="text-purple-100">Atenciones Hoy</p>
                  <p className="text-3xl font-bold">{estadisticas.atencionesHoy}</p>
                </div>
                <FileText className="h-12 w-12 text-purple-200" />
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            <Card className="lg:col-span-1 dark:bg-slate-800">
              <CardHeader>
                <CardTitle className="flex items-center text-slate-800 dark:text-slate-200">
                  <Shield className="h-5 w-5 mr-2 text-sky-600" />
                  Gestión del Sistema
                </CardTitle>
                <CardDescription className="dark:text-slate-400">
                  Administración de usuarios y configuración.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full justify-start" variant="outline" disabled>
                  <Users className="h-4 w-4 mr-2" />
                  Gestionar Usuarios (Próx.)
                </Button>
                <Button className="w-full justify-start" variant="outline" disabled>
                  <Settings className="h-4 w-4 mr-2" />
                  Configuración General (Próx.)
                </Button>
                {verificarPermiso("gestionar_datos") && (
                  <Link href="/datos">
                    <Button className="w-full justify-start" variant="outline">
                      <Database className="h-4 w-4 mr-2" />
                      Gestión de Datos
                    </Button>
                  </Link>
                )}
                <Button className="w-full justify-start" variant="outline" disabled>
                  <Activity className="h-4 w-4 mr-2" />
                  Logs de Actividad (Próx.)
                </Button>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2 dark:bg-slate-800">
              <CardHeader>
                <CardTitle className="flex items-center text-slate-800 dark:text-slate-200">
                  <BarChart3 className="h-5 w-5 mr-2 text-emerald-600" />
                  Acciones Rápidas y Reportes
                </CardTitle>
                <CardDescription className="dark:text-slate-400">
                  Accede a las funcionalidades principales y genera informes.
                </CardDescription>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {verificarPermiso("consultar") && (
                  <Link href="/consultar" className="block">
                    <Button className="w-full justify-start h-auto py-3" variant="outline">
                      <Eye className="h-5 w-5 mr-2 text-sky-500" />
                      <div>
                        <p className="font-semibold">Consultar Estudiantes</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Buscar y ver información.</p>
                      </div>
                    </Button>
                  </Link>
                )}
                {verificarPermiso("registrar") && (
                  <Link href="/registrar" className="block">
                    <Button className="w-full justify-start h-auto py-3" variant="outline">
                      <UserPlus className="h-5 w-5 mr-2 text-green-500" />
                      <div>
                        <p className="font-semibold">Registrar Atenciones</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Nuevas atenciones y remisiones.</p>
                      </div>
                    </Button>
                  </Link>
                )}
                {verificarPermiso("exportar") && (
                  <Link href="/exportar" className="block">
                    <Button className="w-full justify-start h-auto py-3" variant="outline">
                      <Download className="h-5 w-5 mr-2 text-purple-500" />
                      <div>
                        <p className="font-semibold">Generar Reportes</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Exportar datos del sistema.</p>
                      </div>
                    </Button>
                  </Link>
                )}
                {verificarPermiso("ver_tableros") && (
                  <Link href="/exportar/tableros" className="block">
                    <Button className="w-full justify-start h-auto py-3" variant="outline">
                      <BarChart3 className="h-5 w-5 mr-2 text-orange-500" />
                      <div>
                        <p className="font-semibold">Tableros de Control</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Visualizaciones y KPIs.</p>
                      </div>
                    </Button>
                  </Link>
                )}
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gradient-to-r from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center text-slate-800 dark:text-slate-200">
                <Activity className="h-5 w-5 mr-2" />
                Estado del Sistema
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-3 rounded-md bg-white dark:bg-slate-800/50 shadow">
                  <div className="flex items-center justify-center mb-1">
                    <div className="w-3 h-3 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                    <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Base de Datos</span>
                  </div>
                  <Badge
                    variant="outline"
                    className="text-yellow-600 border-yellow-400 dark:text-yellow-400 dark:border-yellow-600"
                  >
                    Simulada (Demo)
                  </Badge>
                </div>
                <div className="text-center p-3 rounded-md bg-white dark:bg-slate-800/50 shadow">
                  <div className="flex items-center justify-center mb-1">
                    <Shield className="h-4 w-4 mr-2 text-slate-500 dark:text-slate-400" />
                    <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Seguridad</span>
                  </div>
                  <Badge
                    variant="outline"
                    className="text-green-600 border-green-400 dark:text-green-400 dark:border-green-600"
                  >
                    Activa (Roles)
                  </Badge>
                </div>
                <div className="text-center p-3 rounded-md bg-white dark:bg-slate-800/50 shadow">
                  <div className="flex items-center justify-center mb-1">
                    <AlertTriangle className="h-4 w-4 mr-2 text-slate-500 dark:text-slate-400" />
                    <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Alertas del Sistema</span>
                  </div>
                  <Badge variant="outline" className="dark:text-slate-300 dark:border-slate-600">
                    0 Activas
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </ProtectedRoute>
  )
}
