"use client"

import { NavigationHeader } from "@/components/navigation-header"
import { ProtectedRoute } from "@/components/protected-route" // Para asegurar que solo usuarios logueados accedan
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { LifeBuoy, Search, UserPlus, Download, Shield, Settings, Phone } from "lucide-react"

const faqData = [
  {
    question: "¿Cómo busco un estudiante?",
    answer:
      "Ve a la sección 'Consultar' en la barra de navegación. Ingresa el número de identificación del estudiante en el campo de búsqueda y presiona 'Buscar'. Se mostrará la información detallada si el estudiante existe en el sistema.",
    icon: <Search className="h-5 w-5 mr-2 text-sky-600" />,
  },
  {
    question: "¿Cómo registro una nueva atención o remisión?",
    answer:
      "Dirígete a la sección 'Registrar'. Primero, busca al estudiante por su ID. Una vez encontrado, podrás seleccionar si deseas registrar una 'Atención Regular' o una 'Remisión a Área'. Completa los campos requeridos y guarda el registro.",
    icon: <UserPlus className="h-5 w-5 mr-2 text-emerald-600" />,
  },
  {
    question: "¿Qué tipos de reportes puedo generar?",
    answer:
      "Si tienes permisos de administrador, puedes ir a la sección 'Exportar'. Allí podrás generar reportes de atenciones, remisiones y listados de estudiantes en formatos como CSV o Excel. Puedes aplicar filtros por fechas, programas, etc.",
    icon: <Download className="h-5 w-5 mr-2 text-purple-600" />,
  },
  {
    question: "¿Cómo funcionan los roles de usuario?",
    answer:
      "Existen tres roles principales: Administrador (acceso total), Registro (consultar y registrar atenciones/remisiones), y Consulta (solo ver información). Tu acceso a las diferentes secciones y funcionalidades dependerá del rol asignado a tu usuario.",
    icon: <Shield className="h-5 w-5 mr-2 text-red-600" />,
  },
  {
    question: "Olvidé mi contraseña, ¿qué hago?",
    answer:
      "Actualmente, la recuperación de contraseña no está automatizada. Por favor, contacta al administrador del sistema (admin@upn.edu.co) para solicitar un restablecimiento de tu contraseña.",
    icon: <Settings className="h-5 w-5 mr-2 text-slate-600" />,
  },
]

export default function AyudaPage() {
  return (
    <ProtectedRoute allowedRoles={["administrador", "consulta", "registro"]} permission="ver_ayuda">
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-yellow-50 dark:from-slate-900 dark:via-slate-800 dark:to-yellow-900">
        <NavigationHeader />
        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="shadow-xl dark:bg-slate-800">
            <CardHeader className="text-center">
              <LifeBuoy className="h-16 w-16 mx-auto mb-4 text-yellow-500" />
              <CardTitle className="text-3xl font-bold text-slate-800 dark:text-slate-100">Centro de Ayuda</CardTitle>
              <CardDescription className="text-lg text-slate-600 dark:text-slate-400 mt-2">
                Encuentra respuestas a tus preguntas frecuentes y aprende a usar el sistema.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              <div>
                <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-200 mb-4">
                  Preguntas Frecuentes (FAQ)
                </h2>
                <Accordion type="single" collapsible className="w-full">
                  {faqData.map((item, index) => (
                    <AccordionItem key={index} value={`item-${index}`} className="dark:border-slate-700">
                      <AccordionTrigger className="text-left hover:no-underline text-slate-700 dark:text-slate-300 hover:text-yellow-600 dark:hover:text-yellow-400">
                        <div className="flex items-center">
                          {item.icon}
                          <span className="font-medium">{item.question}</span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="text-slate-600 dark:text-slate-400 pt-2 pb-4 px-2">
                        {item.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>

              <div className="pt-6 border-t dark:border-slate-700">
                <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-200 mb-4">Contacto de Soporte</h2>
                <Card className="bg-yellow-50 dark:bg-yellow-900/30 border-yellow-200 dark:border-yellow-700">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <Phone className="h-8 w-8 text-yellow-600 dark:text-yellow-400 mt-1" />
                      <div>
                        <p className="text-slate-700 dark:text-slate-200 font-medium">¿Necesitas más ayuda?</p>
                        <p className="text-sm text-slate-600 dark:text-slate-400">
                          Si no encontraste la respuesta a tu pregunta, por favor contacta al equipo de soporte técnico:
                        </p>
                        <ul className="mt-2 text-sm space-y-1">
                          <li>
                            <strong>Email:</strong>{" "}
                            <a
                              href="mailto:soporte.sse@upn.edu.co"
                              className="text-yellow-700 dark:text-yellow-300 hover:underline"
                            >
                              soporte.sse@upn.edu.co
                            </a>
                          </li>
                          <li>
                            <strong>Teléfono:</strong> (601) 594 1894 Ext. 777 (Horario de atención: L-V 8am - 5pm)
                          </li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </ProtectedRoute>
  )
}
