import { type NextRequest, NextResponse } from "next/server"
import * as XLSX from "xlsx"
import { executeQuery, isDatabaseConnected } from "@/lib/database"

// Función para obtener todos los datos necesarios.
// NOTA: Esta función asume que los filtros son simples. Se puede expandir.
async function getReportData() {
  const estudiantes = await executeQuery(
    "SELECT id, nombre, programa, estado, email, telefono, semestre FROM estudiantes",
  )
  const atenciones = await executeQuery(
    "SELECT id, estudiante_id, fecha_atencion, tipo_atencion, descripcion, remision_area, remision_motivo FROM atenciones",
  )
  // Asumimos que las remisiones son un subconjunto de atenciones.
  const remisiones = atenciones.filter((a) => a.remision_area)
  return { estudiantes, atenciones, remisiones }
}

function generarExcel(tipoReporte: string, estudiantes: any[], atenciones: any[], remisiones: any[]) {
  const workbook = XLSX.utils.book_new()

  if (["estudiantes", "consolidado"].includes(tipoReporte)) {
    const wsEstudiantes = XLSX.utils.json_to_sheet(
      estudiantes.map((est) => ({
        ID: est.id,
        Nombre: est.nombre, // Usar la columna correcta 'nombre'
        Programa: est.programa,
        Estado: est.estado,
        Email: est.email,
        Teléfono: est.telefono,
        Semestre: est.semestre,
      })),
    )
    XLSX.utils.book_append_sheet(workbook, wsEstudiantes, "Estudiantes")
  }

  if (["atenciones", "consolidado"].includes(tipoReporte)) {
    const atencionesConNombres = atenciones.map((atencion) => {
      const estudiante = estudiantes.find((est) => est.id === atencion.estudiante_id)
      return {
        "ID Atención": atencion.id,
        "ID Estudiante": atencion.estudiante_id,
        "Nombre Estudiante": estudiante?.nombre || "No encontrado",
        Fecha: atencion.fecha_atencion,
        "Tipo Atención": atencion.tipo_atencion,
        Descripción: atencion.descripcion,
      }
    })
    const wsAtenciones = XLSX.utils.json_to_sheet(atencionesConNombres)
    XLSX.utils.book_append_sheet(workbook, wsAtenciones, "Atenciones")
  }

  if (["remisiones", "consolidado"].includes(tipoReporte)) {
    const remisionesConNombres = remisiones.map((remision) => {
      const estudiante = estudiantes.find((est) => est.id === remision.estudiante_id)
      return {
        "ID Remisión": remision.id,
        "ID Estudiante": remision.estudiante_id,
        "Nombre Estudiante": estudiante?.nombre || "No encontrado",
        Fecha: remision.fecha_atencion,
        "Área Remisión": remision.remision_area,
        Motivo: remision.remision_motivo,
      }
    })
    const wsRemisiones = XLSX.utils.json_to_sheet(remisionesConNombres)
    XLSX.utils.book_append_sheet(workbook, wsRemisiones, "Remisiones")
  }

  const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "buffer" })
  return new NextResponse(excelBuffer, {
    headers: {
      "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition": `attachment; filename="reporte_${tipoReporte}.xlsx"`,
    },
  })
}

export async function POST(request: NextRequest) {
  try {
    const { formato, tipoReporte } = await request.json()

    if (!isDatabaseConnected()) {
      return NextResponse.json({ error: "Base de datos no conectada" }, { status: 503 })
    }

    const { estudiantes, atenciones, remisiones } = await getReportData()

    if (!estudiantes || estudiantes.length === 0) {
      return NextResponse.json({ error: "No se encontraron datos para generar el reporte." }, { status: 404 })
    }

    if (formato === "excel") {
      return generarExcel(tipoReporte, estudiantes, atenciones, remisiones)
    }
    // Aquí se podría añadir la lógica para CSV si se desea.
    return NextResponse.json({ error: "Formato no soportado." }, { status: 400 })
  } catch (error) {
    console.error("Error generando reporte:", error)
    return NextResponse.json({ error: "Error interno del servidor." }, { status: 500 })
  }
}
