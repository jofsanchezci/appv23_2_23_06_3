import { type NextRequest, NextResponse } from "next/server"
import { DatabaseService } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const fechaInicio = searchParams.get("fechaInicio")
    const fechaFin = searchParams.get("fechaFin")

    const db = new DatabaseService()
    const reporte = await db.getReporteGeneral(fechaInicio || undefined, fechaFin || undefined)

    return NextResponse.json(reporte)
  } catch (error) {
    console.error("Error generating report:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
