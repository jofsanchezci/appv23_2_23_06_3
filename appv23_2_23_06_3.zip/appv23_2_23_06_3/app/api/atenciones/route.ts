import { type NextRequest, NextResponse } from "next/server"
import { isDatabaseConnected, executeQuery } from "@/lib/database"

// GET para obtener historial, seleccionando solo columnas existentes
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const estudianteId = searchParams.get("estudiante_id")

  if (!estudianteId) {
    return NextResponse.json({ error: "estudiante_id es requerido" }, { status: 400 })
  }

  if (!isDatabaseConnected()) {
    return NextResponse.json({ error: "Base de datos no conectada" }, { status: 503 })
  }

  try {
    const query = `
      SELECT 
        id, estudiante_id, fecha_atencion, tipo_atencion, descripcion, 
        observaciones, remision_area, remision_motivo, remision_urgencia, 
        remision_seguimiento, remision_fecha_limite
      FROM atenciones 
      WHERE estudiante_id = $1 
      ORDER BY fecha_atencion DESC
    `
    const result = await executeQuery(query, [estudianteId])
    return NextResponse.json(result)
  } catch (error) {
    console.error("Error en GET /api/atenciones:", error)
    return NextResponse.json({ error: "Error interno al obtener atenciones" }, { status: 500 })
  }
}

// POST para registrar atención/remisión, insertando solo en columnas existentes
export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    if (!isDatabaseConnected()) {
      return NextResponse.json({ error: "Base de datos no conectada" }, { status: 503 })
    }
    if (!data.estudiante_id) {
      return NextResponse.json({ error: "El campo 'estudiante_id' es requerido." }, { status: 400 })
    }

    const columns = ["estudiante_id", "tipo_atencion", "descripcion"]
    const params: any[] = [data.estudiante_id, data.tipo_atencion, data.descripcion]

    // Manejo de campos opcionales
    const addParam = (colName: string, value: any) => {
      if (value !== undefined && value !== null && String(value).trim() !== "") {
        columns.push(colName)
        params.push(value)
      }
    }

    const observaciones = data.remision?.observaciones || data.observaciones
    addParam("observaciones", observaciones)

    if (data.remision) {
      addParam("remision_area", data.remision.area)
      addParam("remision_motivo", data.remision.motivo)
      addParam("remision_urgencia", data.remision.urgencia)
      addParam("remision_seguimiento", data.remision.seguimiento)
      addParam("remision_fecha_limite", data.remision.fecha_limite || null)
    }

    const valuesPlaceholders = params.map((_, i) => `$${i + 1}`).join(", ")
    const query = `
      INSERT INTO atenciones (${columns.join(", ")})
      VALUES (${valuesPlaceholders})
      RETURNING *
    `

    const result = await executeQuery(query, params)
    return NextResponse.json(result[0], { status: 201 })
  } catch (error) {
    console.error("Error CRÍTICO en POST /api/atenciones:", error)
    const errorMessage = error instanceof Error ? error.message : "Error interno del servidor"
    return NextResponse.json({ error: errorMessage }, { status: 500 })
  }
}
