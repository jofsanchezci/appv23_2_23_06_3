import { NextResponse } from "next/server"
import { cookies } from "next/headers"

export async function POST() {
  try {
    const cookieStore = cookies()

    // Eliminar cookies de sesión
    cookieStore.delete("session_token")
    cookieStore.delete("user_data")

    return NextResponse.json({ success: true, message: "Logout exitoso" })
  } catch (error) {
    console.error("Error en logout:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
