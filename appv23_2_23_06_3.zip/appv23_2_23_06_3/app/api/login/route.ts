import { type NextRequest, NextResponse } from "next/server"
import { cookies } from "next/headers"

// Usuarios de prueba
const USERS = {
  admin: { id: 1, password: "admin123", rol: "administrador", nombre: "Administrador del Sistema" },
  consulta: { id: 2, password: "consulta123", rol: "consulta", nombre: "Usuario de Consulta" },
  registro: { id: 3, password: "registro123", rol: "registro", nombre: "Usuario de Registro" },
}

export async function POST(request: NextRequest) {
  try {
    const { username, password } = await request.json()

    // Validar campos requeridos
    if (!username || !password) {
      return NextResponse.json({ error: "Usuario y contraseña son requeridos" }, { status: 400 })
    }

    // Verificar credenciales
    const user = USERS[username as keyof typeof USERS]
    if (!user || user.password !== password) {
      return NextResponse.json({ error: "Usuario o contraseña incorrectos" }, { status: 401 })
    }

    // Generar token simple
    const token = Math.random().toString(36).substring(2) + Date.now().toString(36)

    // Configurar cookie de sesión
    const cookieStore = cookies()
    cookieStore.set("session_token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 8 * 60 * 60, // 8 horas
      path: "/",
    })

    // Guardar datos del usuario en cookie (para simplificar)
    cookieStore.set(
      "user_data",
      JSON.stringify({
        id: user.id,
        username,
        rol: user.rol,
        nombre: user.nombre,
      }),
      {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 8 * 60 * 60,
        path: "/",
      },
    )

    return NextResponse.json({
      success: true,
      message: "Login exitoso",
      usuario: {
        id: user.id,
        username,
        rol: user.rol,
        nombre: user.nombre,
      },
    })
  } catch (error) {
    console.error("Error en login:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
