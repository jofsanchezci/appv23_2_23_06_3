import { NextResponse } from "next/server"
import { cookies } from "next/headers"

export async function GET() {
  try {
    const cookieStore = cookies()
    const token = cookieStore.get("session_token")?.value
    const userData = cookieStore.get("user_data")?.value

    if (!token || !userData) {
      return NextResponse.json({ error: "No autenticado" }, { status: 401 })
    }

    const user = JSON.parse(userData)
    return NextResponse.json({ usuario: user })
  } catch (error) {
    console.error("Error obteniendo usuario:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
