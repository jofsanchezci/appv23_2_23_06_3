import { NextResponse } from "next/server"
import { isDatabaseConnected, executeQuery, mockData } from "@/lib/database"

export async function GET() {
  try {
    if (!isDatabaseConnected()) {
      // Estadísticas de prueba
      const estadisticas = {
        total_estudiantes: mockData.estudiantes.length,
        atenciones_mes: mockData.atenciones.length,
        seguimientos_activos: mockData.atenciones.filter((a) => a.estado === "En proceso").length,
        alertas_pendientes: 1,
        por_programa: {
          "Licenciatura en Matemáticas": 1,
          "Licenciatura en Español y Literatura": 1,
          "Licenciatura en Biología": 1,
        },
        por_tipo_atencion: {
          Académica: 1,
          Psicológica: 1,
        },
      }
      return NextResponse.json(estadisticas)
    }

    // Usar base de datos real
    const totalEstudiantes = await executeQuery("SELECT COUNT(*) as count FROM estudiantes")
    const atencionesHoy = await executeQuery(`
      SELECT COUNT(*) as count FROM atenciones 
      WHERE DATE(fecha_atencion) = CURRENT_DATE
    `)
    const seguimientosActivos = await executeQuery(`
      SELECT COUNT(*) as count FROM seguimientos 
      WHERE estado = 'Activo'
    `)

    const estadisticas = {
      total_estudiantes: totalEstudiantes[0]?.count || 0,
      atenciones_hoy: atencionesHoy[0]?.count || 0,
      seguimientos_activos: seguimientosActivos[0]?.count || 0,
      alertas_pendientes: 0,
    }

    return NextResponse.json(estadisticas)
  } catch (error) {
    console.error("Error obteniendo estadísticas:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
