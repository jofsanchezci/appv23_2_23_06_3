import { type NextRequest, NextResponse } from "next/server"
import { isDatabaseConnected, executeQuery, mockData } from "@/lib/database"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get("q") || searchParams.get("termino")

  if (!query) {
    return NextResponse.json({ error: "Parámetro de búsqueda requerido" }, { status: 400 })
  }

  if (!isDatabaseConnected()) {
    console.warn("API /api/buscar: Usando datos de prueba (mock).")
    const resultados = mockData.estudiantes.filter((e) => e.nombre.toLowerCase().includes(query.toLowerCase()))
    return NextResponse.json(resultados)
  }

  try {
    // Consulta corregida: usa la columna 'nombre' y la devuelve como 'nombre_completo'
    const result = await executeQuery(
      `
      SELECT
        id,
        nombre AS nombre_completo, -- Alias para no romper el frontend
        programa,
        semestre,
        email,
        telefono,
        estado
      FROM estudiantes
      WHERE id ILIKE $1
         OR nombre ILIKE $1
      LIMIT 10
      `,
      [`%${query}%`],
    )
    return NextResponse.json(result)
  } catch (error: any) {
    console.error(`Error en API /api/buscar:`, error)
    return NextResponse.json({ error: `Error al buscar estudiantes: ${error.message}` }, { status: 500 })
  }
}
