import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { cerrarSesion } from "@/lib/auth-service"

export async function POST() {
  try {
    const token = cookies().get("session_token")?.value
    if (token) {
      await cerrarSesion(token)
    }
    cookies().delete("session_token")
    return NextResponse.json({ message: "Sesión cerrada exitosamente" })
  } catch (error) {
    console.error("Error en API logout:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
