import { NextResponse, type NextRequest } from "next/server"
import { autenticarUsuario } from "@/lib/auth-service"
import { cookies } from "next/headers"

export async function POST(request: NextRequest) {
  try {
    const { username, contrasena } = await request.json()

    if (!username || !contrasena) {
      return NextResponse.json({ error: "Usuario y contraseña son requeridos" }, { status: 400 })
    }

    const authResult = await autenticarUsuario(username, contrasena)

    if (authResult) {
      const { usuario, token } = authResult
      cookies().set("session_token", token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        maxAge: 60 * 60 * 24 * 7, // 1 semana
        path: "/",
      })
      return NextResponse.json({ usuario })
    } else {
      return NextResponse.json({ error: "Credenciales inválidas" }, { status: 401 })
    }
  } catch (error) {
    console.error("Error en API login:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
