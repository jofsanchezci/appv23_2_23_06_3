import { NextResponse, type NextRequest } from "next/server"
import { obtenerUsuarioPorToken } from "@/lib/auth-service"
import { cookies } from "next/headers"

export async function GET(request: NextRequest) {
  try {
    const token = cookies().get("session_token")?.value

    if (!token) {
      return NextResponse.json({ error: "No autenticado" }, { status: 401 })
    }

    const usuario = await obtenerUsuarioPorToken(token)

    if (usuario) {
      return NextResponse.json({ usuario })
    } else {
      // Token inválido o expirado, limpiar cookie
      cookies().delete("session_token")
      return NextResponse.json({ error: "Sesión inválida" }, { status: 401 })
    }
  } catch (error) {
    console.error("Error en API me:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
