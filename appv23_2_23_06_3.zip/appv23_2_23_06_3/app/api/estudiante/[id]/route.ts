import { type NextRequest, NextResponse } from "next/server"
import { isDatabaseConnected, executeQuery, mockData } from "@/lib/database"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id

    if (!isDatabaseConnected()) {
      // Usar datos de prueba
      const estudiante = mockData.estudiantes.find((e) => e.id.toString() === id)
      if (!estudiante) {
        return NextResponse.json({ error: "Estudiante no encontrado" }, { status: 404 })
      }
      return NextResponse.json(estudiante)
    }

    // Usar base de datos real
    const result = await executeQuery(
      `
      SELECT * FROM estudiantes WHERE id = $1
    `,
      [id],
    )

    if (!result.length) {
      return NextResponse.json({ error: "Estudiante no encontrado" }, { status: 404 })
    }

    return NextResponse.json(result[0])
  } catch (error) {
    console.error("Error obteniendo estudiante:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
