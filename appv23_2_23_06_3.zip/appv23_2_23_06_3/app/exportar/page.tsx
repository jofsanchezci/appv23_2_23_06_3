"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Download, FileText, BarChart3, Filter, AlertCircle, CheckCircle, ArrowLeft, CalendarDays } from "lucide-react"
import { NavigationHeader } from "@/components/navigation-header"
import { ProtectedRoute } from "@/components/protected-route"
import { Label } from "@/components/ui/label"

interface FiltrosReporte {
  tipoReporte: "atenciones" | "remisiones" | "estudiantes" | "consolidado"
  formato: "excel" | "pdf" | "csv"
  rangoFechas: string
  fechaInicio?: string
  fechaFin?: string
  incluirDatosEstudiante: boolean
  incluirDetallesRemision: boolean
  programa: string
  estadoEstudiante: string
}

export default function ExportarPage() {
  const [filtros, setFiltros] = useState<FiltrosReporte>({
    tipoReporte: "atenciones",
    formato: "csv",
    rangoFechas: "ultimos_30_dias",
    incluirDatosEstudiante: true,
    incluirDetallesRemision: true,
    programa: "todos",
    estadoEstudiante: "todos",
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  const handleInputChange = (name: keyof FiltrosReporte, value: any) => {
    setFiltros((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (name: keyof FiltrosReporte, checked: boolean) => {
    setFiltros((prev) => ({ ...prev, [name]: checked }))
  }

  const generarReporte = async () => {
    setLoading(true)
    setError("")
    setSuccess("")

    try {
      const response = await fetch("/api/reportes/generar", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(filtros),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Error al generar el reporte.")
      }

      const blob = await response.blob()
      const contentDisposition = response.headers.get("Content-Disposition")
      let filename = `reporte.zip` // Default filename

      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename="?(.+)"?/)
        if (filenameMatch && filenameMatch.length === 2) {
          filename = filenameMatch[1]
        }
      }

      // Create a link and trigger the download
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = filename
      document.body.appendChild(a)
      a.click()
      a.remove()
      window.URL.revokeObjectURL(url)

      setSuccess(`Reporte "${filename}" generado y descargado exitosamente.`)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <ProtectedRoute allowedRoles={["administrador"]} permission="exportar">
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
        <NavigationHeader />
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Link href="/admin">
                  <Button variant="outline" size="sm">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Volver al Panel Admin
                  </Button>
                </Link>
                <div>
                  <CardTitle className="text-2xl font-bold text-gray-900 flex items-center">
                    <Download className="h-6 w-6 mr-3 text-purple-600" />
                    Exportar Reportes
                  </CardTitle>
                  <CardDescription className="text-gray-600">
                    Genera reportes personalizados del sistema de seguimiento estudiantil.
                  </CardDescription>
                </div>
              </div>
              <Link href="/exportar/tableros">
                <Button variant="outline" className="text-purple-600 border-purple-600 hover:bg-purple-50">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Ver Tableros
                </Button>
              </Link>
            </div>
          </div>
        </header>

        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="shadow-lg">
            <CardContent className="space-y-8 pt-6">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              {success && (
                <Alert className="border-green-200 bg-green-50">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800">{success}</AlertDescription>
                </Alert>
              )}
              <div className="space-y-6 p-6 border rounded-lg bg-gray-50">
                <h3 className="text-lg font-semibold text-gray-800 flex items-center">
                  <Filter className="h-5 w-5 mr-2 text-purple-500" />
                  Configuración del Reporte
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="tipoReporte" className="text-sm font-medium text-gray-700 mb-1">
                      Tipo de Reporte
                    </Label>
                    <Select
                      value={filtros.tipoReporte}
                      onValueChange={(value) => handleInputChange("tipoReporte", value)}
                    >
                      <SelectTrigger id="tipoReporte">
                        <SelectValue placeholder="Selecciona tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="atenciones">Reporte de Atenciones</SelectItem>
                        <SelectItem value="remisiones">Reporte de Remisiones</SelectItem>
                        <SelectItem value="estudiantes">Listado de Estudiantes</SelectItem>
                        <SelectItem value="consolidado">Reporte Consolidado</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="formato" className="text-sm font-medium text-gray-700 mb-1">
                      Formato de Salida
                    </Label>
                    <Select value={filtros.formato} onValueChange={(value) => handleInputChange("formato", value)}>
                      <SelectTrigger id="formato">
                        <SelectValue placeholder="Selecciona formato" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="csv">CSV (Valores Separados por Comas)</SelectItem>
                        <SelectItem value="excel">Excel (XLSX)</SelectItem>
                        <SelectItem value="pdf" disabled>
                          PDF (Próximamente)
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label className="text-sm font-medium text-gray-700 dark:text-slate-300 flex items-center">
                    <CalendarDays className="h-4 w-4 mr-2 text-slate-500" />
                    Rango de Fechas
                  </Label>
                  <Select
                    value={filtros.rangoFechas}
                    onValueChange={(value) => handleInputChange("rangoFechas", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar rango" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos los registros</SelectItem>
                      <SelectItem value="hoy">Hoy</SelectItem>
                      <SelectItem value="ayer">Ayer</SelectItem>
                      <SelectItem value="ultimos_7_dias">Últimos 7 días</SelectItem>
                      <SelectItem value="ultimos_30_dias">Últimos 30 días</SelectItem>
                      <SelectItem value="mes_actual">Este mes</SelectItem>
                      <SelectItem value="mes_anterior">Mes anterior</SelectItem>
                      <SelectItem value="personalizado">Personalizado</SelectItem>
                    </SelectContent>
                  </Select>
                  {filtros.rangoFechas === "personalizado" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
                      <div>
                        <Label htmlFor="fechaInicio" className="text-xs text-slate-600 dark:text-slate-400">
                          Fecha de Inicio
                        </Label>
                        <Input
                          id="fechaInicio"
                          type="date"
                          value={filtros.fechaInicio}
                          onChange={(e) => handleInputChange("fechaInicio", e.target.value)}
                        />
                      </div>
                      <div>
                        <Label htmlFor="fechaFin" className="text-xs text-slate-600 dark:text-slate-400">
                          Fecha de Fin
                        </Label>
                        <Input
                          id="fechaFin"
                          type="date"
                          value={filtros.fechaFin}
                          onChange={(e) => handleInputChange("fechaFin", e.target.value)}
                        />
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <Label className="text-sm font-medium text-gray-700 dark:text-slate-300 flex items-center">
                    <Filter className="h-4 w-4 mr-2 text-slate-500" />
                    Filtros Adicionales
                  </Label>
                  <div className="space-y-4 mt-2 p-4 border rounded-md dark:border-slate-700 bg-slate-50 dark:bg-slate-700/30">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="programa" className="text-xs text-slate-600 dark:text-slate-400">
                          Programa Académico
                        </Label>
                        <Select
                          value={filtros.programa}
                          onValueChange={(value) => handleInputChange("programa", value)}
                        >
                          <SelectTrigger id="programa">
                            <SelectValue placeholder="Todos los programas" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="todos">Todos los programas</SelectItem>
                            <SelectItem value="LICENCIATURA EN EDUCACIÓN BÁSICA PRIMARIA">
                              Lic. Educación Básica
                            </SelectItem>
                            <SelectItem value="LICENCIATURA EN CIENCIAS SOCIALES">Lic. Ciencias Sociales</SelectItem>
                            <SelectItem value="LICENCIATURA EN QUÍMICA">Lic. Química</SelectItem>
                            <SelectItem value="LICENCIATURA EN ARTES VISUALES">Lic. Artes Visuales</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="estadoEstudiante" className="text-xs text-slate-600 dark:text-slate-400">
                          Estado del Estudiante
                        </Label>
                        <Select
                          value={filtros.estadoEstudiante}
                          onValueChange={(value) => handleInputChange("estadoEstudiante", value)}
                        >
                          <SelectTrigger id="estadoEstudiante">
                            <SelectValue placeholder="Todos los estados" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="todos">Todos los estados</SelectItem>
                            <SelectItem value="Matriculado">Matriculado</SelectItem>
                            <SelectItem value="Abandono De Formación">Abandono De Formación</SelectItem>
                            <SelectItem value="Verificar proceso">Verificar proceso</SelectItem>
                            <SelectItem value="Graduado">Graduado</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t dark:border-slate-700">
                  <Button
                    onClick={generarReporte}
                    disabled={loading}
                    className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700 text-white text-base py-3 px-6"
                  >
                    {loading ? (
                      <div className="flex items-center">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Generando...
                      </div>
                    ) : (
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 mr-2" />
                        Generar y Descargar Reporte
                      </div>
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </ProtectedRoute>
  )
}
