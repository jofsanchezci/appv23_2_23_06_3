"use client"

import { NavigationHeader } from "@/components/navigation-header"
import { ProtectedRoute } from "@/components/protected-route"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, LineChart, PieChart, Users, FileText, TrendingUp, AlertTriangle } from "lucide-react"
// Importar Recharts o similar si se van a implementar gráficos reales
// import { BarChart as ReBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart as RePieChart, Pie, Cell } from 'recharts';

// Datos simulados para los gráficos
const atencionesPorMesData = [
  { name: "Ene", atenciones: 65 },
  { name: "Feb", atenciones: 59 },
  { name: "Mar", atenciones: 80 },
  { name: "Abr", atenciones: 81 },
  { name: "May", atenciones: 56 },
  { name: "Jun", atenciones: 70 },
]
const tiposAtencionData = [
  { name: "Académica", value: 400, color: "#8884d8" },
  { name: "Psicológica", value: 300, color: "#82ca9d" },
  { name: "Socioeconómica", value: 200, color: "#ffc658" },
  { name: "Otra", value: 100, color: "#ff8042" },
]
const remisionesPorAreaData = [
  { name: "Bienestar", remisiones: 120 },
  { name: "Coordinación", remisiones: 90 },
  { name: "Admisiones", remisiones: 45 },
  { name: "Otro", remisiones: 30 },
]

export default function TablerosPage() {
  // En una app real, estos datos vendrían de una API
  const kpis = {
    totalAtenciones: 1250,
    totalRemisiones: 285,
    estudiantesAtendidos: 780,
    tasaResolucion: 0.85, // 85%
  }

  return (
    <ProtectedRoute allowedRoles={["administrador"]} permission="ver_tableros">
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-teal-50 dark:from-slate-900 dark:via-slate-800 dark:to-teal-900">
        <NavigationHeader />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-2">Tableros de Control</h1>
            <p className="text-slate-600 dark:text-slate-400">
              Visualización de indicadores clave del sistema de seguimiento.
            </p>
          </div>

          {/* KPIs Principales */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="shadow-lg dark:bg-slate-800">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-700 dark:text-slate-300">
                  Total Atenciones
                </CardTitle>
                <FileText className="h-5 w-5 text-teal-500" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-slate-900 dark:text-slate-100">{kpis.totalAtenciones}</div>
                <p className="text-xs text-slate-500 dark:text-slate-400">+20% mes anterior</p>
              </CardContent>
            </Card>
            <Card className="shadow-lg dark:bg-slate-800">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-700 dark:text-slate-300">
                  Total Remisiones
                </CardTitle>
                <TrendingUp className="h-5 w-5 text-teal-500" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-slate-900 dark:text-slate-100">{kpis.totalRemisiones}</div>
                <p className="text-xs text-slate-500 dark:text-slate-400">+15% mes anterior</p>
              </CardContent>
            </Card>
            <Card className="shadow-lg dark:bg-slate-800">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-700 dark:text-slate-300">
                  Estudiantes Atendidos
                </CardTitle>
                <Users className="h-5 w-5 text-teal-500" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-slate-900 dark:text-slate-100">{kpis.estudiantesAtendidos}</div>
                <p className="text-xs text-slate-500 dark:text-slate-400">Únicos este semestre</p>
              </CardContent>
            </Card>
            <Card className="shadow-lg dark:bg-slate-800">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-700 dark:text-slate-300">
                  Tasa de Resolución
                </CardTitle>
                <AlertTriangle className="h-5 w-5 text-orange-500" /> {/* O un icono de check si es bueno */}
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-slate-900 dark:text-slate-100">
                  {(kpis.tasaResolucion * 100).toFixed(0)}%
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">Casos cerrados exitosamente</p>
              </CardContent>
            </Card>
          </div>

          {/* Gráficos */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <Card className="shadow-lg dark:bg-slate-800">
              <CardHeader>
                <CardTitle className="flex items-center text-slate-800 dark:text-slate-100">
                  <LineChart className="h-5 w-5 mr-2 text-teal-600" />
                  Atenciones por Mes (Últimos 6 meses)
                </CardTitle>
              </CardHeader>
              <CardContent className="h-[300px] flex items-center justify-center">
                {/* Aquí iría el componente de gráfico real, ej: <RechartsLineChart data={atencionesPorMesData} /> */}
                <p className="text-slate-500 dark:text-slate-400">Gráfico de Atenciones por Mes (Simulado)</p>
                {/* <ResponsiveContainer width="100%" height="100%">
                  <ReBarChart data={atencionesPorMesData}>
                    <CartesianGrid strokeDasharray="3 3" className="dark:stroke-slate-700" />
                    <XAxis dataKey="name" className="dark:fill-slate-400" />
                    <YAxis className="dark:fill-slate-400" />
                    <Tooltip contentStyle={{ backgroundColor: 'rgba(var(--background))', border: '1px solid rgba(var(--border))' }} />
                    <Legend />
                    <Bar dataKey="atenciones" fill="rgba(var(--chart-1))" radius={[4, 4, 0, 0]} />
                  </ReBarChart>
                </ResponsiveContainer> */}
              </CardContent>
            </Card>

            <Card className="shadow-lg dark:bg-slate-800">
              <CardHeader>
                <CardTitle className="flex items-center text-slate-800 dark:text-slate-100">
                  <PieChart className="h-5 w-5 mr-2 text-teal-600" />
                  Distribución por Tipo de Atención
                </CardTitle>
              </CardHeader>
              <CardContent className="h-[300px] flex items-center justify-center">
                <p className="text-slate-500 dark:text-slate-400">Gráfico de Tipos de Atención (Simulado)</p>
                {/* <ResponsiveContainer width="100%" height="100%">
                  <RePieChart>
                    <Pie data={tiposAtencionData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                      {tiposAtencionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: 'rgba(var(--background))', border: '1px solid rgba(var(--border))' }} />
                    <Legend />
                  </RePieChart>
                </ResponsiveContainer> */}
              </CardContent>
            </Card>
          </div>

          <Card className="shadow-lg dark:bg-slate-800">
            <CardHeader>
              <CardTitle className="flex items-center text-slate-800 dark:text-slate-100">
                <BarChart className="h-5 w-5 mr-2 text-teal-600" />
                Remisiones por Área de Destino
              </CardTitle>
            </CardHeader>
            <CardContent className="h-[300px] flex items-center justify-center">
              <p className="text-slate-500 dark:text-slate-400">Gráfico de Remisiones por Área (Simulado)</p>
              {/* Aquí iría el componente de gráfico real, ej: <RechartsBarChart data={remisionesPorAreaData} /> */}
            </CardContent>
          </Card>

          <div className="mt-8 text-center">
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Los datos presentados son simulados y para fines demostrativos.
            </p>
          </div>
        </main>
      </div>
    </ProtectedRoute>
  )
}
