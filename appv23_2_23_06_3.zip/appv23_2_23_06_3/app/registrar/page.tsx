"use client"

import { useState, useEffect, useCallback } from "react"
import Link from "next/link"
import { useSearchParams, useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import {
  ArrowLeft,
  UserPlus,
  Search,
  CheckCircle,
  AlertCircle,
  User,
  Calendar,
  BookOpen,
  Send,
  FileText,
  Clock,
  MapPin,
  Info,
} from "lucide-react"
import { NavigationHeader } from "@/components/navigation-header"
import { ProtectedRoute } from "@/components/protected-route"
import { Label } from "@/components/ui/label"

interface Estudiante {
  id: string // ID es string, corresponde al PK VARCHAR(20) de la tabla estudiantes
  nombre_completo: string
  programa: string
  estado: string
  semestre?: string | number
  email?: string
  telefono?: string
}
interface Atencion {
  id: number // PK numérico de la tabla atenciones
  estudiante_id: string // FK al id string del estudiante
  fecha: string // Formato para mostrar: DD/MM/YYYY
  fecha_atencion?: string // ISO String desde la BD
  descripcion: string
  tipo_atencion: string
  remision?: Remision
  observaciones?: string
}
interface Remision {
  area: string
  motivo: string
  urgencia: string
  observaciones: string
  seguimiento: boolean
  fecha_limite?: string | null
}
interface AreaUniversidad {
  id: string
  nombre: string
  descripcion: string
  responsable: string
  email: string
  telefono: string
  horario: string
  ubicacion: string
  icon: string
}

const estudiantesDataForDisplay: Record<string, { nombre: string }> = {
  "52269833": { nombre: "NORMA CONSTANZA AVILA MONCADA" },
  "1000494871": { nombre: "JOSE SNEIDER SUAREZ MENDEZ" },
  "1022384479": { nombre: "JOHN STIVEN FLOREZ MACANA" },
}

const areasUniversidad: AreaUniversidad[] = [
  {
    id: "bienestar-psicosocial",
    nombre: "Bienestar Universitario - Apoyo Psicosocial",
    descripcion: "Atención Psicológica Individual - Atención en Crisis",
    responsable: "N/A",
    email: "bienestar.psicosocial@upn.edu.co",
    telefono: "N/A",
    horario: "N/A",
    ubicacion: "Bienestar Universitario",
    icon: "🧠",
  },
  {
    id: "bienestar-socioeconomico",
    nombre: "Bienestar Universitario - Programa Socioeconómico",
    descripcion: "Almuerzo Subsidiado, Monitorias ASE, convenios",
    responsable: "N/A",
    email: "bienestar.socioeconomico@upn.edu.co",
    telefono: "N/A",
    horario: "N/A",
    ubicacion: "Bienestar Universitario",
    icon: "💰",
  },
  {
    id: "bienestar-cultura",
    nombre: "Bienestar Universitario - Programa de Cultura, Deporte y Recreación",
    descripcion: "Actividades culturales, deportivas y recreativas",
    responsable: "N/A",
    email: "bienestar.cultura@upn.edu.co",
    telefono: "N/A",
    horario: "N/A",
    ubicacion: "Bienestar Universitario",
    icon: "🎨",
  },
  {
    id: "bienestar-convivencia",
    nombre: "Bienestar Universitario - Programa de Convivencia",
    descripcion: "Promoción de la sana convivencia y resolución de conflictos",
    responsable: "N/A",
    email: "bienestar.convivencia@upn.edu.co",
    telefono: "N/A",
    horario: "N/A",
    ubicacion: "Bienestar Universitario",
    icon: "🤝",
  },
  {
    id: "bienestar-genero",
    nombre: "Bienestar Universitario - Programa de Género y Cuidado",
    descripcion: "Apoyo y orientación en temas de género y cuidado",
    responsable: "N/A",
    email: "bienestar.genero@upn.edu.co",
    telefono: "N/A",
    horario: "N/A",
    ubicacion: "Bienestar Universitario",
    icon: "⚖️",
  },
  {
    id: "coordinacion-academica",
    nombre: "Coordinación Académica",
    descripcion: "Tutorías académicas, orientación en procesos académicos",
    responsable: "N/A",
    email: "coordinacion.academica@upn.edu.co",
    telefono: "N/A",
    horario: "N/A",
    ubicacion: "Coordinación Académica",
    icon: "📚",
  },
  {
    id: "vicerrectoria-academica",
    nombre: "Vicerrectoría Académica",
    descripcion: "Permanencia, CADEP, Biblioteca",
    responsable: "N/A",
    email: "vicerrectoria.academica@upn.edu.co",
    telefono: "N/A",
    horario: "N/A",
    ubicacion: "Vicerrectoría Académica",
    icon: "🏛️",
  },
  {
    id: "admisiones-registro",
    nombre: "Subdirección de Admisiones y Registro",
    descripcion: "Procesos Académicos - Administrativos",
    responsable: "N/A",
    email: "admisiones.registro@upn.edu.co",
    telefono: "N/A",
    horario: "N/A",
    ubicacion: "Admisiones y Registro",
    icon: "📋",
  },
]
const tiposAtencion = [
  {
    value: "seguimiento-docentes-tutores",
    label: "Seguimiento Docentes - Tutores",
    description: "Seguimiento y coordinación con docentes tutores.",
  },
  {
    value: "acompanamiento-academico",
    label: "Acompañamiento Académico",
    description: "Apoyo en procesos de aprendizaje y rendimiento académico.",
  },
  {
    value: "acompanamiento-psicologico",
    label: "Acompañamiento Psicológico",
    description: "Apoyo emocional y psicológico al estudiante.",
  },
  {
    value: "orientacion-salud",
    label: "Orientación en Salud",
    description: "Orientación sobre temas de salud y bienestar físico.",
  },
  {
    value: "orientacion-socioeconomica",
    label: "Orientación Socioeconómica",
    description: "Apoyo en temas económicos, becas y ayudas financieras.",
  },
  {
    value: "orientacion-convivencia",
    label: "Orientación Convivencia",
    description: "Orientación en temas de convivencia universitaria.",
  },
  {
    value: "orientacion-vocacional",
    label: "Orientación Vocacional (Transferencia Interna o Externa)",
    description: "Orientación para cambios de programa o transferencias.",
  },
  {
    value: "orientacion-tramites-administrativos",
    label: "Orientación en Trámites Administrativos",
    description: "Cancelación, reintegros, nueva admisión, proceso de grado, etc.",
  },
  {
    value: "orientacion-registro-academico",
    label: "Orientación en Registro Académico",
    description: "Orientación sobre certificados, notas y registros académicos.",
  },
  {
    value: "orientacion-proceso-matricula",
    label: "Orientación Proceso de Matrícula",
    description: "Apoyo en procesos de matrícula y renovación.",
  },
  {
    value: "orientacion-abandono-formacion",
    label: "Orientación Abandono de Formación",
    description: "Orientación sobre procesos de abandono y alternativas.",
  },
]
const nivelesUrgencia = [
  {
    value: "baja",
    label: "Baja",
    color: "bg-green-100 text-green-800 dark:bg-green-800/30 dark:text-green-300",
    description: "No requiere atención inmediata",
  },
  {
    value: "media",
    label: "Media",
    color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-800/30 dark:text-yellow-300",
    description: "Atención en los próximos días",
  },
  {
    value: "alta",
    label: "Alta",
    color: "bg-red-100 text-red-800 dark:bg-red-800/30 dark:text-red-300",
    description: "Requiere atención prioritaria",
  },
]

export default function RegistrarPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const [paso, setPaso] = useState(1)
  const [busqueda, setBusqueda] = useState("")
  const [estudiante, setEstudiante] = useState<Estudiante | null>(null)
  const [atenciones, setAtenciones] = useState<Atencion[]>([])
  const [tipoRegistro, setTipoRegistro] = useState<"atencion" | "remision">("atencion")
  const [nuevaAtencion, setNuevaAtencion] = useState({ tipo: "", descripcion: "" })
  const [nuevaRemision, setNuevaRemision] = useState<Remision>({
    area: "",
    motivo: "",
    urgencia: "media",
    observaciones: "",
    seguimiento: false,
    fecha_limite: "",
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  const fetchStudentAndAttentions = useCallback(
    async (studentIdToSearch: string) => {
      // Renombrado para claridad, este es el ID de búsqueda (ej: "1022...")
      setLoading(true)
      setError("")
      setEstudiante(null)
      setAtenciones([])

      try {
        const studentRes = await fetch(`/api/buscar?termino=${encodeURIComponent(studentIdToSearch)}`)
        if (!studentRes.ok) {
          const errorData = await studentRes.json().catch(() => ({}))
          throw new Error(errorData.error || "Error al buscar el estudiante.")
        }
        const studentDataArray = await studentRes.json()

        if (!studentDataArray || !Array.isArray(studentDataArray) || studentDataArray.length === 0) {
          setError(`Estudiante con ID ${studentIdToSearch} no encontrado. Verifica el ID o regístralo si es nuevo.`)
          setPaso(1)
          // No limpiar URL aquí para que el usuario vea el ID que buscó
          return
        }

        const foundStudent: Estudiante = studentDataArray[0] // API devuelve un array
        setEstudiante(foundStudent) // foundStudent.id ya es string

        if (foundStudent && foundStudent.id) {
          // foundStudent.id es el PK string de la tabla estudiantes
          const attentionsRes = await fetch(`/api/atenciones?estudiante_id=${foundStudent.id}`)
          if (attentionsRes.ok) {
            const attentionsData: Atencion[] = await attentionsRes.json()
            setAtenciones(
              attentionsData.map((att) => ({
                ...att,
                fecha: new Date(att.fecha_atencion!).toLocaleDateString("es-ES", {
                  // Usar fecha_atencion de la BD
                  year: "numeric",
                  month: "2-digit",
                  day: "2-digit",
                }),
              })),
            )
          } else {
            console.warn("No se pudieron cargar las atenciones del estudiante.")
            setAtenciones([])
          }
        }
        setPaso(2)
      } catch (err: any) {
        setError(err.message || "Ocurrió un error al cargar los datos del estudiante.")
        setPaso(1)
      } finally {
        setLoading(false)
      }
    },
    [], // router no es necesario como dependencia si no se usa dentro
  )

  useEffect(() => {
    const studentIdParam = searchParams.get("id_estudiante") // Este es el ID de búsqueda
    if (studentIdParam && !estudiante && !loading) {
      // Evitar re-fetch si ya está cargado o cargando
      fetchStudentAndAttentions(studentIdParam)
    }
  }, [searchParams, fetchStudentAndAttentions, estudiante, loading])

  const handleBuscarEstudiante = () => {
    if (!busqueda.trim()) {
      setError("Por favor ingresa un ID de estudiante.")
      return
    }
    fetchStudentAndAttentions(busqueda.trim())
  }

  const registrarAtencion = async () => {
    if (!nuevaAtencion.tipo || !nuevaAtencion.descripcion.trim()) {
      setError("Por favor completa todos los campos de la atención.")
      return
    }
    if (!estudiante || !estudiante.id) {
      // estudiante.id es string
      setError("No se ha seleccionado un estudiante válido.")
      return
    }

    setLoading(true)
    setError("")

    try {
      const payload = {
        estudiante_id: estudiante.id, // Enviar el ID string del estudiante
        tipo_atencion: tiposAtencion.find((t) => t.value === nuevaAtencion.tipo)?.label || nuevaAtencion.tipo,
        descripcion: nuevaAtencion.descripcion.trim(),
      }

      const response = await fetch("/api/atenciones", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(errorData.error || "Error al registrar la atención.")
      }

      const nuevaAtencionRegistrada: Atencion = await response.json()

      setAtenciones((prev) => [
        {
          ...nuevaAtencionRegistrada,
          fecha: new Date(nuevaAtencionRegistrada.fecha_atencion!).toLocaleDateString("es-ES", {
            year: "numeric",
            month: "2-digit",
            day: "2-digit",
          }),
        },
        ...prev,
      ])
      setSuccess("¡Atención registrada exitosamente en la base de datos!")
      setNuevaAtencion({ tipo: "", descripcion: "" })
      setPaso(3)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const registrarRemision = async () => {
    if (!nuevaRemision.area || !nuevaRemision.motivo.trim()) {
      setError("Por favor completa los campos obligatorios de la remisión.")
      return
    }
    if (!estudiante || !estudiante.id) {
      // estudiante.id es string
      setError("No se ha seleccionado un estudiante válido.")
      return
    }

    setLoading(true)
    setError("")

    try {
      const areaSeleccionada = areasUniversidad.find((a) => a.id === nuevaRemision.area)
      const payload = {
        estudiante_id: estudiante.id, // Enviar el ID string del estudiante
        tipo_atencion: "Remisión",
        descripcion: `Remisión a ${areaSeleccionada?.nombre}: ${nuevaRemision.motivo.trim()}`,
        remision: {
          area: nuevaRemision.area,
          motivo: nuevaRemision.motivo.trim(),
          urgencia: nuevaRemision.urgencia,
          observaciones: nuevaRemision.observaciones.trim(),
          seguimiento: nuevaRemision.seguimiento,
          fecha_limite: nuevaRemision.fecha_limite || null,
        },
      }

      const response = await fetch("/api/atenciones", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(errorData.error || "Error al registrar la remisión.")
      }

      const nuevaRemisionRegistrada: Atencion = await response.json()

      setAtenciones((prev) => [
        {
          ...nuevaRemisionRegistrada,
          fecha: new Date(nuevaRemisionRegistrada.fecha_atencion!).toLocaleDateString("es-ES", {
            year: "numeric",
            month: "2-digit",
            day: "2-digit",
          }),
        },
        ...prev,
      ])
      setSuccess(`¡Remisión a ${areaSeleccionada?.nombre} registrada exitosamente en la base de datos!`)
      setNuevaRemision({
        area: "",
        motivo: "",
        urgencia: "media",
        observaciones: "",
        seguimiento: false,
        fecha_limite: "",
      })
      setPaso(3)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const reiniciarFormulario = () => {
    setPaso(1)
    setBusqueda("")
    setEstudiante(null)
    setAtenciones([])
    setNuevaAtencion({ tipo: "", descripcion: "" })
    setNuevaRemision({
      area: "",
      motivo: "",
      urgencia: "media",
      observaciones: "",
      seguimiento: false,
      fecha_limite: "",
    })
    setTipoRegistro("atencion")
    setError("")
    setSuccess("")
    router.replace("/registrar", undefined) // Limpia parámetros de la URL
  }

  const getUrgenciaStyle = (urgencia: string) => {
    const nivel = nivelesUrgencia.find((n) => n.value === urgencia)
    return nivel?.color || "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300"
  }

  return (
    <ProtectedRoute allowedRoles={["administrador", "registro"]} permission="registrar">
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-emerald-50 dark:from-slate-900 dark:via-slate-800 dark:to-emerald-900">
        <NavigationHeader />
        <header className="bg-white dark:bg-slate-800 shadow-sm border-b dark:border-slate-700">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Link href="/consultar">
                  <Button
                    variant="outline"
                    size="icon"
                    className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
                  >
                    <ArrowLeft className="h-5 w-5" />
                  </Button>
                </Link>
                <div>
                  <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
                    Registrar Atención / Remisión
                  </h1>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Sistema de seguimiento estudiantil UPN</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-slate-500 dark:text-slate-400">Paso {paso} de 3</p>
                <div className="flex space-x-1 mt-1">
                  {[1, 2, 3].map((num) => (
                    <div
                      key={num}
                      className={`w-2.5 h-2.5 rounded-full ${num <= paso ? "bg-emerald-500" : "bg-slate-300 dark:bg-slate-600"}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {error && (
            <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-700 rounded-md flex items-center">
              <AlertCircle className="h-5 w-5 text-red-500 dark:text-red-400 mr-3" />
              <span className="text-red-700 dark:text-red-300">{error}</span>
            </div>
          )}
          {success && (
            <div className="mb-6 p-4 bg-green-50 dark:bg-green-900/30 border border-green-200 dark:border-green-700 rounded-md flex items-center">
              <CheckCircle className="h-5 w-5 text-green-500 dark:text-green-400 mr-3" />
              <span className="text-green-700 dark:text-green-300 font-medium">{success}</span>
            </div>
          )}

          {paso === 1 && !estudiante && (
            <div className="space-y-6">
              <Card className="shadow-lg dark:bg-slate-800">
                <CardHeader>
                  <CardTitle className="flex items-center text-slate-800 dark:text-slate-100">
                    <Search className="h-5 w-5 mr-2 text-emerald-600" />
                    Paso 1: Buscar Estudiante
                  </CardTitle>
                  <CardDescription className="dark:text-slate-400">
                    Ingresa el número de identificación del estudiante.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex space-x-3">
                    <Input
                      placeholder="Número de identificación (ej: 1022384479)"
                      value={busqueda}
                      onChange={(e) => setBusqueda(e.target.value)}
                      className="flex-1 dark:bg-slate-700 dark:text-slate-200 dark:placeholder-slate-500"
                      onKeyPress={(e) => e.key === "Enter" && handleBuscarEstudiante()}
                    />
                    <Button
                      onClick={handleBuscarEstudiante}
                      disabled={loading}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white"
                    >
                      {loading ? "Buscando..." : "Buscar"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-sky-50 dark:bg-sky-900/30 border-sky-200 dark:border-sky-700">
                <CardHeader>
                  <CardTitle className="text-sky-800 dark:text-sky-300 flex items-center">
                    <Info className="h-5 w-5 mr-2" /> IDs de Prueba (para copiar y pegar)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {Object.entries(estudiantesDataForDisplay).map(([id, est]) => (
                      <div
                        key={id}
                        className="bg-white dark:bg-slate-700/50 p-3 rounded-lg border dark:border-slate-600"
                      >
                        <code className="text-sm font-mono text-sky-600 dark:text-sky-400">{id}</code>
                        <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">{est.nombre}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {paso === 2 && estudiante && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="space-y-6">
                <Card className="dark:bg-slate-800">
                  <CardHeader>
                    <CardTitle className="flex items-center text-slate-800 dark:text-slate-100">
                      <User className="h-5 w-5 mr-2 text-sky-600" />
                      Información del Estudiante
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="dark:text-slate-300">
                    <div className="space-y-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold text-lg">{estudiante.nombre_completo}</h3>
                          <p className="text-slate-600 dark:text-slate-400 text-sm">{estudiante.programa}</p>
                        </div>
                        <Badge
                          variant={
                            estudiante.estado === "Matriculado" || estudiante.estado === "Activo"
                              ? "default"
                              : estudiante.estado === "Graduado"
                                ? "secondary"
                                : "destructive"
                          }
                          className={
                            estudiante.estado === "Matriculado" || estudiante.estado === "Activo"
                              ? "bg-green-500 text-white"
                              : estudiante.estado === "Graduado"
                                ? "bg-blue-500 text-white"
                                : "bg-red-500 text-white"
                          }
                        >
                          {estudiante.estado}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-1 gap-3 text-sm">
                        <div>
                          <p className="text-slate-500 dark:text-slate-400">ID:</p>{" "}
                          <p className="font-medium">{estudiante.id}</p> {/* Mostrar estudiante.id */}
                        </div>
                        <div>
                          <p className="text-slate-500 dark:text-slate-400">Semestre:</p>{" "}
                          <p className="font-medium">{estudiante.semestre || "N/A"}</p>
                        </div>
                        <div>
                          <p className="text-slate-500 dark:text-slate-400">Email:</p>{" "}
                          <p className="font-medium text-xs">{estudiante.email || "N/A"}</p>
                        </div>
                        <div>
                          <p className="text-slate-500 dark:text-slate-400">Teléfono:</p>{" "}
                          <p className="font-medium">{estudiante.telefono || "N/A"}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="dark:bg-slate-800">
                  <CardHeader>
                    <CardTitle className="flex items-center text-slate-800 dark:text-slate-100">
                      <Calendar className="h-5 w-5 mr-2 text-sky-600" />
                      Historial ({atenciones.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {atenciones.length > 0 ? (
                      <div className="space-y-3 max-h-64 overflow-y-auto pr-2">
                        {atenciones.map((atencion) => (
                          <div
                            key={atencion.id} // PK de la atención
                            className="border-l-4 border-emerald-500 pl-4 py-2 bg-slate-50 dark:bg-slate-700/50 rounded-r-md"
                          >
                            <div className="flex justify-between items-start mb-1">
                              <Badge variant="outline" className="dark:border-slate-600 dark:text-slate-300">
                                {atencion.tipo_atencion}
                              </Badge>
                              <span className="text-xs text-slate-500 dark:text-slate-400">{atencion.fecha}</span>
                            </div>
                            <p className="text-sm text-slate-700 dark:text-slate-300 mb-2">{atencion.descripcion}</p>
                            {atencion.remision && (
                              <div className="bg-sky-50 dark:bg-sky-900/40 p-2 rounded text-xs mt-1">
                                <div className="flex items-center mb-1">
                                  <Send className="h-3 w-3 mr-1 text-sky-600 dark:text-sky-400" />
                                  <span className="font-medium text-sky-700 dark:text-sky-300">Remitido a:</span>
                                </div>
                                <p className="text-sky-700 dark:text-sky-300">
                                  {areasUniversidad.find((a) => a.id === atencion.remision?.area)?.nombre}
                                </p>
                                <div className="flex items-center mt-1">
                                  <span
                                    className={`px-2 py-0.5 rounded-full text-xs ${getUrgenciaStyle(atencion.remision.urgencia)}`}
                                  >
                                    {nivelesUrgencia.find((n) => n.value === atencion.remision?.urgencia)?.label}
                                  </span>
                                  {atencion.remision.seguimiento && (
                                    <Badge
                                      variant="outline"
                                      className="ml-2 text-xs dark:border-slate-600 dark:text-slate-300"
                                    >
                                      <Clock className="h-3 w-3 mr-1" /> Seguimiento
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-slate-500 dark:text-slate-400 text-center py-4">
                        No hay atenciones registradas.
                      </p>
                    )}
                  </CardContent>
                </Card>
              </div>

              <div className="lg:col-span-2">
                <Card className="dark:bg-slate-800">
                  <CardHeader>
                    <CardTitle className="flex items-center text-slate-800 dark:text-slate-100">
                      <UserPlus className="h-5 w-5 mr-2 text-emerald-600" />
                      Paso 2: Registrar Atención o Remisión
                    </CardTitle>
                    <CardDescription className="dark:text-slate-400">Selecciona el tipo de registro.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Tabs
                      value={tipoRegistro}
                      onValueChange={(value) => setTipoRegistro(value as "atencion" | "remision")}
                      className="dark:text-slate-300"
                    >
                      <TabsList className="grid w-full grid-cols-2 dark:bg-slate-700">
                        <TabsTrigger
                          value="atencion"
                          className="flex items-center data-[state=active]:bg-emerald-500 data-[state=active]:text-white dark:data-[state=active]:bg-emerald-600"
                        >
                          <FileText className="h-4 w-4 mr-2" /> Atención Regular
                        </TabsTrigger>
                        <TabsTrigger
                          value="remision"
                          className="flex items-center data-[state=active]:bg-sky-500 data-[state=active]:text-white dark:data-[state=active]:bg-sky-600"
                        >
                          <Send className="h-4 w-4 mr-2" /> Remisión a Área
                        </TabsTrigger>
                      </TabsList>

                      <TabsContent value="atencion" className="space-y-6 mt-6">
                        <div>
                          <Label className="block text-sm font-medium mb-2 dark:text-slate-300">
                            Tipo de Atención *
                          </Label>
                          <Select onValueChange={(value) => setNuevaAtencion({ ...nuevaAtencion, tipo: value })}>
                            <SelectTrigger className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200">
                              <SelectValue placeholder="Selecciona el tipo de atención" />
                            </SelectTrigger>
                            <SelectContent className="dark:bg-slate-800 dark:border-slate-700">
                              {tiposAtencion.map((tipo) => (
                                <SelectItem key={tipo.value} value={tipo.value} className="dark:focus:bg-slate-700">
                                  <div>
                                    <div className="font-medium dark:text-slate-200">{tipo.label}</div>
                                    <div className="text-xs text-slate-500 dark:text-slate-400">{tipo.description}</div>
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label className="block text-sm font-medium mb-2 dark:text-slate-300">
                            Descripción de la Atención *
                          </Label>
                          <Textarea
                            placeholder="Describe detalladamente la atención..."
                            value={nuevaAtencion.descripcion}
                            onChange={(e) => setNuevaAtencion({ ...nuevaAtencion, descripcion: e.target.value })}
                            rows={6}
                            className="resize-none dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200 dark:placeholder-slate-500"
                          />
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                            {nuevaAtencion.descripcion.length}/500
                          </p>
                        </div>
                        <div className="flex space-x-4">
                          <Button
                            onClick={reiniciarFormulario}
                            variant="outline"
                            className="flex-1 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
                          >
                            Cancelar
                          </Button>
                          <Button
                            onClick={registrarAtencion}
                            disabled={loading}
                            className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white"
                          >
                            {loading ? "Registrando..." : "Registrar Atención"}
                          </Button>
                        </div>
                      </TabsContent>

                      <TabsContent value="remision" className="space-y-6 mt-6">
                        <div>
                          <Label className="block text-sm font-medium mb-2 dark:text-slate-300">
                            Área de Destino *
                          </Label>
                          <Select onValueChange={(value) => setNuevaRemision({ ...nuevaRemision, area: value })}>
                            <SelectTrigger className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200">
                              <SelectValue placeholder="Selecciona el área a remitir" />
                            </SelectTrigger>
                            <SelectContent className="dark:bg-slate-800 dark:border-slate-700">
                              {areasUniversidad.map((area) => (
                                <SelectItem key={area.id} value={area.id} className="dark:focus:bg-slate-700">
                                  <div className="flex items-center">
                                    <span className="mr-2 text-lg">{area.icon}</span>
                                    <div>
                                      <div className="font-medium dark:text-slate-200">{area.nombre}</div>
                                      <div className="text-xs text-slate-500 dark:text-slate-400">
                                        {area.descripcion}
                                      </div>
                                    </div>
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {nuevaRemision.area && (
                            <div className="mt-3 p-3 bg-sky-50 dark:bg-sky-900/30 rounded-lg border dark:border-sky-700">
                              {(() => {
                                const areaSel = areasUniversidad.find((a) => a.id === nuevaRemision.area)
                                return areaSel ? (
                                  <div className="text-sm">
                                    <div className="flex items-center mb-2">
                                      <span className="text-xl mr-2">{areaSel.icon}</span>
                                      <span className="font-medium text-sky-700 dark:text-sky-300">
                                        {areaSel.nombre}
                                      </span>
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1 text-xs text-slate-600 dark:text-slate-400">
                                      <div>
                                        <span className="font-medium">Responsable:</span> {areaSel.responsable}
                                      </div>
                                      <div>
                                        <span className="font-medium">Email:</span> {areaSel.email}
                                      </div>
                                      <div>
                                        <span className="font-medium">Teléfono:</span> {areaSel.telefono}
                                      </div>
                                      <div className="flex items-center">
                                        <MapPin className="h-3 w-3 mr-1" />
                                        {areaSel.ubicacion}
                                      </div>
                                      <div className="md:col-span-2">
                                        <span className="font-medium">Horario:</span> {areaSel.horario}
                                      </div>
                                    </div>
                                  </div>
                                ) : null
                              })()}
                            </div>
                          )}
                        </div>
                        <div>
                          <Label className="block text-sm font-medium mb-2 dark:text-slate-300">
                            Motivo de la Remisión *
                          </Label>
                          <Textarea
                            placeholder="Explica detalladamente el motivo..."
                            value={nuevaRemision.motivo}
                            onChange={(e) => setNuevaRemision({ ...nuevaRemision, motivo: e.target.value })}
                            rows={4}
                            className="resize-none dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200 dark:placeholder-slate-500"
                          />
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                            {nuevaRemision.motivo.length}/300
                          </p>
                        </div>
                        <div>
                          <Label className="block text-sm font-medium mb-2 dark:text-slate-300">
                            Nivel de Urgencia
                          </Label>
                          <Select
                            value={nuevaRemision.urgencia}
                            onValueChange={(value) => setNuevaRemision({ ...nuevaRemision, urgencia: value })}
                          >
                            <SelectTrigger className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="dark:bg-slate-800 dark:border-slate-700">
                              {nivelesUrgencia.map((nivel) => (
                                <SelectItem key={nivel.value} value={nivel.value} className="dark:focus:bg-slate-700">
                                  <div className="flex items-center">
                                    <span className={`w-3 h-3 rounded-full mr-2 ${nivel.color.split(" ")[0]}`}></span>
                                    <div>
                                      <div className="font-medium dark:text-slate-200">{nivel.label}</div>
                                      <div className="text-xs text-slate-500 dark:text-slate-400">
                                        {nivel.description}
                                      </div>
                                    </div>
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label className="block text-sm font-medium mb-2 dark:text-slate-300">
                            Observaciones Adicionales
                          </Label>
                          <Textarea
                            placeholder="Información adicional relevante..."
                            value={nuevaRemision.observaciones}
                            onChange={(e) => setNuevaRemision({ ...nuevaRemision, observaciones: e.target.value })}
                            rows={3}
                            className="resize-none dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200 dark:placeholder-slate-500"
                          />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="seguimiento"
                              checked={nuevaRemision.seguimiento}
                              onCheckedChange={(checked) =>
                                setNuevaRemision({ ...nuevaRemision, seguimiento: checked as boolean })
                              }
                              className="dark:border-slate-600 data-[state=checked]:bg-sky-500 data-[state=checked]:border-sky-500"
                            />
                            <Label htmlFor="seguimiento" className="text-sm font-medium dark:text-slate-300">
                              Requiere seguimiento
                            </Label>
                          </div>
                          {nuevaRemision.seguimiento && (
                            <div>
                              <Label className="block text-sm font-medium mb-1 dark:text-slate-300">
                                Fecha límite seguimiento
                              </Label>
                              <Input
                                type="date"
                                value={nuevaRemision.fecha_limite || ""}
                                onChange={(e) => setNuevaRemision({ ...nuevaRemision, fecha_limite: e.target.value })}
                                min={new Date().toISOString().split("T")[0]}
                                className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200"
                              />
                            </div>
                          )}
                        </div>
                        <div className="flex space-x-4">
                          <Button
                            onClick={reiniciarFormulario}
                            variant="outline"
                            className="flex-1 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
                          >
                            Cancelar
                          </Button>
                          <Button
                            onClick={registrarRemision}
                            disabled={loading}
                            className="flex-1 bg-sky-600 hover:bg-sky-700 text-white"
                          >
                            {loading ? "Procesando..." : "Registrar Remisión"}
                          </Button>
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {paso === 3 && (
            <Card className="shadow-lg dark:bg-slate-800">
              <CardContent className="text-center py-12">
                <CheckCircle className="h-20 w-20 text-emerald-500 dark:text-emerald-400 mx-auto mb-6" />
                <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-4">
                  {tipoRegistro === "atencion" ? "¡Atención Registrada!" : "¡Remisión Procesada!"}
                </h2>
                <p className="text-slate-600 dark:text-slate-400 mb-2">{success}</p>
                <p className="text-sm text-slate-500 dark:text-slate-500 mb-8">
                  Fecha: {new Date().toLocaleDateString("es-ES", { year: "numeric", month: "2-digit", day: "2-digit" })}
                </p>
                <div className="flex flex-col sm:flex-row justify-center space-y-3 sm:space-y-0 sm:space-x-4">
                  <Button onClick={reiniciarFormulario} className="bg-emerald-600 hover:bg-emerald-700 text-white">
                    <UserPlus className="h-4 w-4 mr-2" />
                    Nuevo Registro
                  </Button>
                  <Link href="/consultar">
                    <Button
                      variant="outline"
                      className="w-full sm:w-auto dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
                    >
                      <BookOpen className="h-4 w-4 mr-2" />
                      Consultar Estudiantes
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    </ProtectedRoute>
  )
}
