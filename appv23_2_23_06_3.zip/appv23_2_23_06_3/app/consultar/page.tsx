"use client"

import { Label } from "@/components/ui/label"
import { useState, useEffect } from "react" // Importar useEffect
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, User, Mail, Phone, GraduationCap, Calendar, FilePlus } from "lucide-react"
import { NavigationHeader } from "@/components/navigation-header"
import { ProtectedRoute } from "@/components/protected-route"
import { useAuth } from "@/components/auth-provider"

const estudiantesEjemplo = [
  {
    id: "52269833",
    nombre: "NORMA CONSTANZA AVILA MONCADA",
    programa: "LICENCIATURA EN EDUCACIÓN BÁSICA PRIMARIA",
    estado: "Verificar proceso",
    semestre: "8",
    email: "ncavilam@upn.edu.co",
    telefono: "3224127779",
    edad: "48.9",
  },
  {
    id: "1000494871",
    nombre: "JOSE SNEIDER SUAREZ MENDEZ",
    programa: "LICENCIATURA EN CIENCIAS SOCIALES",
    estado: "06. Abandono De Formación",
    semestre: "8",
    email: "jssuarezm@upn.edu.co",
    telefono: "3007544066",
    edad: "21.4",
  },
  {
    id: "1022384479",
    nombre: "JOHN STIVEN FLOREZ MACANA",
    programa: "LICENCIATURA EN QUÍMICA",
    estado: "01. Matriculado",
    semestre: "8",
    email: "josflorezm@upn.edu.co",
    telefono: "3232233961",
    edad: "31.6",
  },
]

export default function ConsultarPage() {
  const { usuario, verificarPermiso } = useAuth() // Obtener el objeto 'usuario' completo
  const [busqueda, setBusqueda] = useState("")
  const [estudiante, setEstudiante] = useState<any>(null)
  const [cargando, setCargando] = useState(false)
  const [error, setError] = useState("")

  // Hacemos la verificación de permisos más explícita y fácil de depurar.
  const puedeRegistrar = verificarPermiso("registrar")

  // Para depuración: puedes verificar en la consola del navegador si el permiso es correcto.
  useEffect(() => {
    if (usuario) {
      console.log(`Usuario: ${usuario.username}, Rol: ${usuario.rol}, Puede Registrar: ${puedeRegistrar}`)
    }
  }, [usuario, puedeRegistrar])

  const buscarEstudiante = () => {
    if (!busqueda.trim()) {
      setError("Por favor ingresa un ID de estudiante")
      return
    }
    setCargando(true)
    setError("")
    setTimeout(() => {
      const estudianteEncontrado = estudiantesEjemplo.find((e) => e.id === busqueda.trim())
      if (estudianteEncontrado) {
        setEstudiante(estudianteEncontrado)
        setError("")
      } else {
        setEstudiante(null)
        setError("Estudiante no encontrado. Intenta con: 52269833, 1000494871, o 1022384479")
      }
      setCargando(false)
    }, 1000)
  }

  const getEstadoBadge = (estado: string) => {
    if (estado.includes("Matriculado")) return "bg-green-100 text-green-800 dark:bg-green-800/30 dark:text-green-300"
    if (estado.includes("Graduado")) return "bg-blue-100 text-blue-800 dark:bg-blue-800/30 dark:text-blue-300"
    if (estado.includes("Abandono")) return "bg-red-100 text-red-800 dark:bg-red-800/30 dark:text-red-300"
    return "bg-yellow-100 text-yellow-800 dark:bg-yellow-800/30 dark:text-yellow-300"
  }

  return (
    <ProtectedRoute allowedRoles={["administrador", "consulta", "registro"]} permission="consultar">
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-sky-50 dark:from-slate-900 dark:via-slate-800 dark:to-sky-900">
        <NavigationHeader />
        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="mb-8 shadow-lg dark:bg-slate-800">
            <CardHeader>
              <CardTitle className="flex items-center text-2xl text-slate-800 dark:text-slate-100">
                <Search className="h-6 w-6 mr-3 text-sky-600" />
                Consultar Estudiante
              </CardTitle>
              <CardDescription className="dark:text-slate-400">
                Ingresa el número de identificación del estudiante para ver su información detallada.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-3">
                <Input
                  placeholder="ID del estudiante (ej: 52269833)"
                  value={busqueda}
                  onChange={(e) => setBusqueda(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && buscarEstudiante()}
                  className="flex-1 dark:bg-slate-700 dark:text-slate-200 dark:placeholder-slate-500"
                />
                <Button
                  onClick={buscarEstudiante}
                  disabled={cargando}
                  className="bg-sky-600 hover:bg-sky-700 text-white"
                >
                  {cargando ? "Buscando..." : "Buscar"}
                </Button>
              </div>
              {error && <p className="text-red-500 dark:text-red-400 text-sm mt-3">{error}</p>}
            </CardContent>
          </Card>

          {estudiante && (
            <Card className="shadow-lg dark:bg-slate-800">
              <CardHeader>
                <CardTitle className="flex items-center text-xl text-slate-800 dark:text-slate-100">
                  <User className="h-5 w-5 mr-2 text-sky-600" />
                  Información del Estudiante
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                  <div>
                    <Label className="text-xs text-slate-500 dark:text-slate-400">Nombre Completo</Label>
                    <p className="font-medium text-slate-700 dark:text-slate-200">{estudiante.nombre}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500 dark:text-slate-400">Número de Identificación</Label>
                    <p className="font-medium text-slate-700 dark:text-slate-200">{estudiante.id}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500 dark:text-slate-400">Email</Label>
                    <p className="font-medium text-slate-700 dark:text-slate-200 text-sm flex items-center">
                      <Mail className="h-4 w-4 mr-1.5 text-slate-400 dark:text-slate-500" />
                      {estudiante.email}
                    </p>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500 dark:text-slate-400">Teléfono</Label>
                    <p className="font-medium text-slate-700 dark:text-slate-200 flex items-center">
                      <Phone className="h-4 w-4 mr-1.5 text-slate-400 dark:text-slate-500" />
                      {estudiante.telefono}
                    </p>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500 dark:text-slate-400">Programa Académico</Label>
                    <p className="font-medium text-slate-700 dark:text-slate-200 flex items-center">
                      <GraduationCap className="h-4 w-4 mr-1.5 text-slate-400 dark:text-slate-500" />
                      {estudiante.programa}
                    </p>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500 dark:text-slate-400">Semestre</Label>
                    <p className="font-medium text-slate-700 dark:text-slate-200">{estudiante.semestre}°</p>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500 dark:text-slate-400">Edad</Label>
                    <p className="font-medium text-slate-700 dark:text-slate-200 flex items-center">
                      <Calendar className="h-4 w-4 mr-1.5 text-slate-400 dark:text-slate-500" />
                      {estudiante.edad} años
                    </p>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500 dark:text-slate-400">Estado Académico</Label>
                    <Badge className={`mt-1 ${getEstadoBadge(estudiante.estado)}`}>{estudiante.estado}</Badge>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 pt-4 border-t dark:border-slate-700">
                  {/* Usamos la variable 'puedeRegistrar' para la condición. Esto es clave. */}
                  {puedeRegistrar && (
                    <Link
                      href={`/registrar?id_estudiante=${estudiante.id}&nombre=${encodeURIComponent(estudiante.nombre)}`}
                      className="w-full sm:w-auto"
                    >
                      <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
                        <FilePlus className="h-4 w-4 mr-2" />
                        Registrar Atención/Remisión
                      </Button>
                    </Link>
                  )}
                  <Button
                    variant="outline"
                    className="w-full sm:w-auto dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
                  >
                    Ver Historial Completo (Próx.)
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {!estudiante && !cargando && (
            <Card className="mt-8 bg-sky-50 dark:bg-sky-900/30 border-sky-200 dark:border-sky-700">
              <CardContent className="p-6 text-center">
                <Search className="h-12 w-12 text-sky-500 dark:text-sky-400 mx-auto mb-3" />
                <h3 className="font-semibold text-sky-800 dark:text-sky-300 mb-1">Busca un estudiante</h3>
                <p className="text-sky-600 dark:text-sky-500 text-sm">
                  Utiliza el campo de arriba para encontrar la información de un estudiante por su ID.
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-4">
                  IDs de prueba: 52269833, 1000494871, 1022384479
                </p>
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    </ProtectedRoute>
  )
}
