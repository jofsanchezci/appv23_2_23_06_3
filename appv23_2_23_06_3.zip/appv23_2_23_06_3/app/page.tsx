"use client"

import { useEffect } from "react"
import { useAuth } from "@/components/auth-provider"
import { useRouter } from "next/navigation"
import Image from "next/image"

export default function HomePage() {
  const { usuario, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading) {
      if (usuario) {
        const dashboardPorRol = {
          administrador: "/admin",
          registro: "/registrar",
          consulta: "/consultar",
        }
        router.replace(dashboardPorRol[usuario.rol] || "/consultar")
      } else {
        router.replace("/login")
      }
    }
  }, [usuario, loading, router])

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-red-900 p-4">
      <Image
        src="/logo-apoyo-estudiantil-upn.png"
        alt="Logo Apoyo Estudiantil UPN"
        width={150}
        height={150}
        className="mx-auto mb-6 rounded-full animate-pulse"
      />
      <h1 className="text-3xl font-bold text-white mb-4">Sistema de Seguimiento Estudiantil</h1>
      <p className="text-slate-300 mb-8">Universidad Pedagógica Nacional</p>
      <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-white"></div>
      <p className="text-white mt-4">Cargando aplicación...</p>
    </div>
  )
}
