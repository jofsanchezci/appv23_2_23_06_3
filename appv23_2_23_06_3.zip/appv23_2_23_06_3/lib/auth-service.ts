// Este archivo simula una base de datos de usuarios y la lógica de autenticación.
// En una aplicación real, esto interactuaría con una base de datos real y usaría hashing de contraseñas.

import type { Usuario } from "@/components/auth-provider" // Asegúrate que la ruta sea correcta

const usuariosSimulados: Usuario[] = [
  {
    id: 1,
    username: "admin",
    password: "adminpassword", // En una app real, esto sería un hash
    email: "admin@upn.edu.co",
    nombre_completo: "Administrador del Sistema",
    rol: "administrador",
  },
  {
    id: 2,
    username: "consulta",
    password: "consultapassword",
    email: "consulta@upn.edu.co",
    nombre_completo: "Usuario de Consulta",
    rol: "consulta",
  },
  {
    id: 3,
    username: "registro",
    password: "registropassword",
    email: "registro@upn.edu.co",
    nombre_completo: "Usuario de Registro",
    rol: "registro",
  },
]

// Simulación de tokens de sesión
const sesionesActivas: Record<string, number> = {} // token -> userId

export async function autenticarUsuario(
  username: string,
  contrasena: string,
): Promise<{ usuario: Omit<Usuario, "password">; token: string } | null> {
  const usuario = usuariosSimulados.find((u) => u.username === username && u.password === contrasena)
  if (usuario) {
    const token = `fake-session-token-${Date.now()}-${Math.random()}`
    sesionesActivas[token] = usuario.id
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { password, ...usuarioSinContrasena } = usuario
    return { usuario: usuarioSinContrasena, token }
  }
  return null
}

export async function obtenerUsuarioPorToken(token: string): Promise<Omit<Usuario, "password"> | null> {
  const userId = sesionesActivas[token]
  if (userId) {
    const usuario = usuariosSimulados.find((u) => u.id === userId)
    if (usuario) {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { password, ...usuarioSinContrasena } = usuario
      return usuarioSinContrasena
    }
  }
  return null
}

export async function cerrarSesion(token: string): Promise<void> {
  delete sesionesActivas[token]
}

export function verificarPermisosRol(rol: Usuario["rol"], accion: string): boolean {
  const permisosPorRol: Record<Usuario["rol"], string[]> = {
    administrador: ["ver_admin", "consultar", "registrar", "exportar", "gestionar_datos", "ver_ayuda", "ver_tableros"],
    consulta: ["consultar", "ver_ayuda"],
    // El rol 'registro' tiene los permisos correctos:
    registro: ["consultar", "registrar", "ver_ayuda"],
  }
  return permisosPorRol[rol]?.includes(accion) || false
}
