import { neon, type NeonQueryFunction } from "@neondatabase/serverless"

let sql: NeonQueryFunction<false, false> | null = null

if (process.env.DATABASE_URL) {
  try {
    sql = neon(process.env.DATABASE_URL)
    console.log("Conexión a Neon DB inicializada exitosamente.")
  } catch (error) {
    console.error("Error CRÍTICO al inicializar la conexión a Neon DB:", error)
  }
} else {
  console.warn("ADVERTENCIA: La variable de entorno DATABASE_URL NO está definida.")
}

export async function executeQuery(query: string, params: any[] = []) {
  if (!sql) {
    throw new Error("Error de base de datos: La conexión no está disponible.")
  }
  try {
    return await sql.query(query, params)
  } catch (error) {
    console.error(`Error ejecutando consulta SQL: "${query}" con params: ${JSON.stringify(params)}`, error)
    throw error
  }
}

export function isDatabaseConnected(): boolean {
  return sql !== null
}

// MockData actualizado para coincidir con el esquema
export const mockData = {
  estudiantes: [
    {
      id: "MOCK001",
      nombre: "Estudiante Mock Uno Ejemplo",
      nombre_completo: "Estudiante Mock Uno Ejemplo", // El alias que usa el front
      programa: "Programa Mock",
      estado: "Activo",
    },
  ],
  atenciones: [
    {
      id: 1,
      estudiante_id: "MOCK001",
      tipo_atencion: "Académica Mock",
      descripcion: "Descripción de atención mock",
      fecha_atencion: new Date().toISOString(),
      observaciones: "Observación de prueba",
    },
  ],
}

export { sql }
