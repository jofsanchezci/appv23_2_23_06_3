"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState, useCallback } from "react"
import { useRouter, usePathname } from "next/navigation"
import { verificarPermisosRol } from "@/lib/auth-service" // Importar la función de permisos

export interface Usuario {
  id: number
  username: string
  password?: string // Solo para la simulación en auth-service, no se expone
  email: string
  nombre_completo: string
  rol: "administrador" | "consulta" | "registro"
}

interface AuthContextType {
  usuario: Omit<Usuario, "password"> | null
  loading: boolean
  login: (username: string, contrasena: string) => Promise<boolean>
  logout: () => Promise<void>
  verificarPermiso: (accion: string) => boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [usuario, setUsuario] = useState<Omit<Usuario, "password"> | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const pathname = usePathname()

  const verificarAutenticacion = useCallback(async () => {
    if (pathname === "/login") {
      setLoading(false)
      return
    }
    try {
      const response = await fetch("/api/auth/me")
      if (response.ok) {
        const data = await response.json()
        setUsuario(data.usuario)
        if (pathname === "/" && data.usuario) {
          redirigirPorRol(data.usuario.rol)
        }
      } else {
        setUsuario(null)
        if (pathname !== "/login") {
          router.push("/login?origen=" + pathname)
        }
      }
    } catch (error) {
      console.error("Error verificando autenticación:", error)
      setUsuario(null)
      if (pathname !== "/login") {
        router.push("/login?origen=" + pathname)
      }
    } finally {
      setLoading(false)
    }
  }, [pathname, router])

  useEffect(() => {
    verificarAutenticacion()
  }, [verificarAutenticacion])

  const redirigirPorRol = (rol: Usuario["rol"]) => {
    const dashboardPorRol: Record<Usuario["rol"], string> = {
      administrador: "/admin",
      registro: "/registrar",
      consulta: "/consultar",
    }
    router.push(dashboardPorRol[rol] || "/consultar")
  }

  const login = async (username: string, contrasena: string): Promise<boolean> => {
    setLoading(true)
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, contrasena }),
      })
      if (response.ok) {
        const data = await response.json()
        setUsuario(data.usuario)
        redirigirPorRol(data.usuario.rol)
        return true
      }
      setUsuario(null)
      return false
    } catch (error) {
      console.error("Error en login:", error)
      setUsuario(null)
      return false
    } finally {
      setLoading(false)
    }
  }

  const logout = async () => {
    setLoading(true)
    try {
      await fetch("/api/auth/logout", { method: "POST" })
    } catch (error) {
      console.error("Error en logout API:", error)
    } finally {
      setUsuario(null)
      router.push("/login")
      setLoading(false)
    }
  }

  const verificarPermiso = (accion: string): boolean => {
    if (!usuario) return false
    return verificarPermisosRol(usuario.rol, accion)
  }

  if (loading && pathname !== "/login") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Verificando sesión...</p>
        </div>
      </div>
    )
  }

  return (
    <AuthContext.Provider value={{ usuario, loading, login, logout, verificarPermiso }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth debe ser usado dentro de un AuthProvider")
  }
  return context
}
