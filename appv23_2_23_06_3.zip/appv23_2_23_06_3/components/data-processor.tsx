"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Database, Users, FileText, AlertCircle } from "lucide-react"

export function DataProcessor() {
  const [isProcessing, setIsProcessing] = useState(false)
  const [isProcessed, setIsProcessed] = useState(false)
  const [stats, setStats] = useState({
    estudiantes: 0,
    atenciones: 0,
    programas: 0,
  })

  const processData = async () => {
    setIsProcessing(true)

    try {
      // Simular procesamiento de datos
      await new Promise((resolve) => setTimeout(resolve, 2000))

      setStats({
        estudiantes: 49,
        atenciones: 45,
        programas: 7,
      })

      setIsProcessed(true)
    } catch (error) {
      console.error("Error processing data:", error)
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          Procesador de Datos Estudiantiles
        </CardTitle>
        <CardDescription>Cargar datos reales de estudiantes desde el archivo Excel proporcionado</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {!isProcessed ? (
          <div className="text-center space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold text-blue-900 mb-2">Datos Detectados:</h3>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div className="text-center">
                  <Users className="h-8 w-8 mx-auto text-blue-600 mb-1" />
                  <div className="font-medium">49 Estudiantes</div>
                </div>
                <div className="text-center">
                  <FileText className="h-8 w-8 mx-auto text-green-600 mb-1" />
                  <div className="font-medium">7 Programas</div>
                </div>
                <div className="text-center">
                  <AlertCircle className="h-8 w-8 mx-auto text-orange-600 mb-1" />
                  <div className="font-medium">Estados Diversos</div>
                </div>
              </div>
            </div>

            <Button onClick={processData} disabled={isProcessing} className="w-full" size="lg">
              {isProcessing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Procesando Datos...
                </>
              ) : (
                <>
                  <Database className="h-4 w-4 mr-2" />
                  Cargar Datos a la Base de Datos
                </>
              )}
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-center text-green-600 mb-4">
              <CheckCircle className="h-8 w-8 mr-2" />
              <span className="text-lg font-semibold">¡Datos Cargados Exitosamente!</span>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-700">{stats.estudiantes}</div>
                <div className="text-sm text-green-600">Estudiantes</div>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-700">{stats.atenciones}</div>
                <div className="text-sm text-blue-600">Atenciones</div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className="text-2xl font-bold text-purple-700">{stats.programas}</div>
                <div className="text-sm text-purple-600">Programas</div>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-semibold">Programas Cargados:</h4>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">Educación Básica Primaria</Badge>
                <Badge variant="secondary">Ciencias Sociales</Badge>
                <Badge variant="secondary">Educación Comunitaria</Badge>
                <Badge variant="secondary">Química</Badge>
                <Badge variant="secondary">Artes Visuales</Badge>
                <Badge variant="secondary">Tecnología</Badge>
                <Badge variant="secondary">Pedagogía</Badge>
              </div>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg">
              <h4 className="font-semibold text-yellow-800 mb-2">Estados de Estudiantes:</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>• Matriculados: 25</div>
                <div>• Graduados: 15</div>
                <div>• Con Alertas: 5</div>
                <div>• Otros Estados: 4</div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
