"use client"

import Link from "next/link"
import Image from "next/image"
import { useAuth } from "./auth-provider"
import { Button } from "@/components/ui/button"
import { BarChart3, LogOut, UserPlus, Search, Download, ShieldCheck, Database, LifeBuoy, Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function NavigationHeader() {
  const { usuario, logout, verificarPermiso } = useAuth()
  const { theme, setTheme } = useTheme()

  if (!usuario) {
    return null // No mostrar header si no hay usuario (ej. en página de login)
  }

  const getInitials = (name: string) => {
    const names = name.split(" ")
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase()
    }
    return name.substring(0, 2).toUpperCase()
  }

  return (
    <header className="bg-slate-800 text-white shadow-md sticky top-0 z-50">
      <div className="max-w-full mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-2">
              <Image
                src="/logo-apoyo-estudiantil-upn.png"
                alt="UPN Logo"
                width={40}
                height={40}
                className="rounded-md"
              />
              <span className="font-semibold text-lg hidden md:block">Seguimiento UPN</span>
            </Link>
          </div>

          <nav className="hidden md:flex space-x-4 items-center">
            {verificarPermiso("ver_admin") && (
              <Link
                href="/admin"
                className="hover:text-red-300 px-3 py-2 rounded-md text-sm font-medium flex items-center"
              >
                <ShieldCheck className="h-4 w-4 mr-1" /> Admin
              </Link>
            )}
            {verificarPermiso("consultar") && (
              <Link
                href="/consultar"
                className="hover:text-red-300 px-3 py-2 rounded-md text-sm font-medium flex items-center"
              >
                <Search className="h-4 w-4 mr-1" /> Consultar
              </Link>
            )}
            {verificarPermiso("registrar") && (
              <Link
                href="/registrar"
                className="hover:text-red-300 px-3 py-2 rounded-md text-sm font-medium flex items-center"
              >
                <UserPlus className="h-4 w-4 mr-1" /> Registrar
              </Link>
            )}
            {verificarPermiso("exportar") && (
              <Link
                href="/exportar"
                className="hover:text-red-300 px-3 py-2 rounded-md text-sm font-medium flex items-center"
              >
                <Download className="h-4 w-4 mr-1" /> Exportar
              </Link>
            )}
            {verificarPermiso("ver_tableros") && (
              <Link
                href="/exportar/tableros"
                className="hover:text-red-300 px-3 py-2 rounded-md text-sm font-medium flex items-center"
              >
                <BarChart3 className="h-4 w-4 mr-1" /> Tableros
              </Link>
            )}
            {verificarPermiso("gestionar_datos") && (
              <Link
                href="/datos"
                className="hover:text-red-300 px-3 py-2 rounded-md text-sm font-medium flex items-center"
              >
                <Database className="h-4 w-4 mr-1" /> Datos
              </Link>
            )}
            {verificarPermiso("ver_ayuda") && (
              <Link
                href="/ayuda"
                className="hover:text-red-300 px-3 py-2 rounded-md text-sm font-medium flex items-center"
              >
                <LifeBuoy className="h-4 w-4 mr-1" /> Ayuda
              </Link>
            )}
          </nav>

          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "light" ? "dark" : "light")}
              className="hover:bg-slate-700"
            >
              <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              <span className="sr-only">Toggle theme</span>
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-10 rounded-full hover:bg-slate-700 p-0">
                  <Avatar className="h-8 w-8">
                    <AvatarImage
                      src={`https://avatar.vercel.sh/${usuario.username}.png`}
                      alt={usuario.nombre_completo}
                    />
                    <AvatarFallback>{getInitials(usuario.nombre_completo)}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 bg-white dark:bg-slate-800" align="end" forceMount>
                <DropdownMenuItem className="focus:bg-slate-100 dark:focus:bg-slate-700">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none text-slate-900 dark:text-slate-50">
                      {usuario.nombre_completo}
                    </p>
                    <p className="text-xs leading-none text-slate-500 dark:text-slate-400">{usuario.email}</p>
                    <p className="text-xs leading-none text-sky-600 dark:text-sky-400 capitalize">{usuario.rol}</p>
                  </div>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-slate-200 dark:bg-slate-700" />
                <DropdownMenuItem
                  onClick={logout}
                  className="text-red-600 dark:text-red-400 focus:bg-red-50 dark:focus:bg-red-900/50 cursor-pointer"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Cerrar Sesión
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  )
}
