"use client"

import type React from "react"

import { useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { useAuth } from "./auth-provider" // Asegúrate que la ruta sea correcta
import type { Usuario } from "./auth-provider"

interface ProtectedRouteProps {
  children: React.ReactNode
  allowedRoles: Usuario["rol"][]
  permission?: string // Permiso específico opcional dentro del rol
}

export function ProtectedRoute({ children, allowedRoles, permission }: ProtectedRouteProps) {
  const { usuario, loading, verificarPermiso } = useAuth()
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    if (!loading && !usuario) {
      router.push(`/login?origen=${pathname}`)
      return
    }

    if (!loading && usuario) {
      const tieneRolPermitido = allowedRoles.includes(usuario.rol)
      const tienePermisoEspecifico = permission ? verificarPermiso(permission) : true

      if (!tieneRolPermitido || !tienePermisoEspecifico) {
        // Redirigir a una página de "acceso denegado" o al dashboard por defecto del rol
        // Por simplicidad, redirigimos al dashboard por defecto del rol o a una página genérica de no autorizado
        const dashboardPorRol: Record<Usuario["rol"], string> = {
          administrador: "/admin",
          registro: "/registrar",
          consulta: "/consultar",
        }
        router.push(dashboardPorRol[usuario.rol] || "/consultar") // O una página /unauthorized
      }
    }
  }, [usuario, loading, router, allowedRoles, pathname, permission, verificarPermiso])

  if (loading || !usuario) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Cargando...</p>
        </div>
      </div>
    )
  }

  const tieneRolPermitido = allowedRoles.includes(usuario.rol)
  const tienePermisoEspecifico = permission ? verificarPermiso(permission) : true

  if (tieneRolPermitido && tienePermisoEspecifico) {
    return <>{children}</>
  }

  // Este return es un fallback, aunque useEffect debería haber redirigido.
  // Podrías mostrar un mensaje de "Acceso denegado" aquí también.
  return null
}
