"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  BarChart3,
  TrendingUp,
  Users,
  AlertTriangle,
  CheckCircle,
  Clock,
  Send,
  BookOpen,
  FileText,
  Calendar,
  Filter,
} from "lucide-react"

interface DashboardData {
  totalEstudiantes: number
  atencionesHoy: number
  remisionesActivas: number
  seguimientosPendientes: number
  atencionesPorTipo: { tipo: string; cantidad: number; color: string }[]
  remisionesPorArea: { area: string; cantidad: number; urgencia: string }[]
  tendenciaMensual: { mes: string; atenciones: number; remisiones: number }[]
  programasConMasAtenciones: { programa: string; cantidad: number; porcentaje: number }[]
  estadisticasUrgencia: { nivel: string; cantidad: number; color: string }[]
}

export function DashboardCharts() {
  const [data, setData] = useState<DashboardData | null>(null)
  const [filtroTiempo, setFiltroTiempo] = useState("mes")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simular carga de datos
    setTimeout(() => {
      setData({
        totalEstudiantes: 49,
        atencionesHoy: 8,
        remisionesActivas: 12,
        seguimientosPendientes: 5,
        atencionesPorTipo: [
          { tipo: "Acompañamiento Académico", cantidad: 15, color: "bg-blue-500" },
          { tipo: "Acompañamiento Psicológico", cantidad: 12, color: "bg-green-500" },
          { tipo: "Orientación Socioeconómica", cantidad: 8, color: "bg-yellow-500" },
          { tipo: "Orientación en Trámites", cantidad: 10, color: "bg-purple-500" },
          { tipo: "Seguimiento Docentes", cantidad: 6, color: "bg-red-500" },
          { tipo: "Orientación Vocacional", cantidad: 4, color: "bg-indigo-500" },
        ],
        remisionesPorArea: [
          { area: "Bienestar - Psicosocial", cantidad: 8, urgencia: "alta" },
          { area: "Bienestar - Socioeconómico", cantidad: 6, urgencia: "media" },
          { area: "Coordinación Académica", cantidad: 5, urgencia: "baja" },
          { area: "Vicerrectoría Académica", cantidad: 3, urgencia: "media" },
          { area: "Admisiones y Registro", cantidad: 4, urgencia: "alta" },
        ],
        tendenciaMensual: [
          { mes: "Sep", atenciones: 25, remisiones: 8 },
          { mes: "Oct", atenciones: 32, remisiones: 12 },
          { mes: "Nov", atenciones: 28, remisiones: 10 },
          { mes: "Dic", atenciones: 35, remisiones: 15 },
          { mes: "Ene", atenciones: 42, remisiones: 18 },
        ],
        programasConMasAtenciones: [
          { programa: "Ciencias Sociales", cantidad: 18, porcentaje: 32 },
          { programa: "Educación Básica Primaria", cantidad: 15, porcentaje: 27 },
          { programa: "Química", cantidad: 12, porcentaje: 21 },
          { programa: "Artes Visuales", cantidad: 8, porcentaje: 14 },
          { programa: "Otros", cantidad: 3, porcentaje: 6 },
        ],
        estadisticasUrgencia: [
          { nivel: "Alta", cantidad: 8, color: "bg-red-500" },
          { nivel: "Media", cantidad: 15, color: "bg-yellow-500" },
          { nivel: "Baja", cantidad: 12, color: "bg-green-500" },
        ],
      })
      setLoading(false)
    }, 1500)
  }, [filtroTiempo])

  if (loading) {
    return (
      <div className="space-y-6">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-32 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  if (!data) return null

  return (
    <div className="space-y-6">
      {/* Filtros */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <Filter className="h-5 w-5 mr-2" />
                Filtros de Visualización
              </CardTitle>
              <CardDescription>Personaliza la vista de los tableros</CardDescription>
            </div>
            <div className="flex space-x-2">
              <Select value={filtroTiempo} onValueChange={setFiltroTiempo}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="semana">Última Semana</SelectItem>
                  <SelectItem value="mes">Último Mes</SelectItem>
                  <SelectItem value="trimestre">Último Trimestre</SelectItem>
                  <SelectItem value="semestre">Último Semestre</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <Calendar className="h-4 w-4 mr-2" />
                Personalizar
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Métricas Principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100">Total Estudiantes</p>
                <p className="text-3xl font-bold">{data.totalEstudiantes}</p>
                <p className="text-xs text-blue-200 mt-1">En seguimiento activo</p>
              </div>
              <Users className="h-12 w-12 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100">Atenciones Hoy</p>
                <p className="text-3xl font-bold">{data.atencionesHoy}</p>
                <p className="text-xs text-green-200 mt-1">+15% vs ayer</p>
              </div>
              <CheckCircle className="h-12 w-12 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100">Remisiones Activas</p>
                <p className="text-3xl font-bold">{data.remisionesActivas}</p>
                <p className="text-xs text-purple-200 mt-1">En proceso</p>
              </div>
              <Send className="h-12 w-12 text-purple-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-100">Seguimientos Pendientes</p>
                <p className="text-3xl font-bold">{data.seguimientosPendientes}</p>
                <p className="text-xs text-orange-200 mt-1">Requieren atención</p>
              </div>
              <Clock className="h-12 w-12 text-orange-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Gráficos Principales */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Atenciones por Tipo */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="h-5 w-5 mr-2" />
              Atenciones por Tipo
            </CardTitle>
            <CardDescription>Distribución de tipos de atención en el último mes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.atencionesPorTipo.map((item, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <div className={`w-4 h-4 rounded ${item.color}`}></div>
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm font-medium">{item.tipo}</span>
                      <span className="text-sm text-gray-600">{item.cantidad}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${item.color}`}
                        style={{ width: `${(item.cantidad / 20) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Remisiones por Área */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Send className="h-5 w-5 mr-2" />
              Remisiones por Área
            </CardTitle>
            <CardDescription>Áreas con mayor número de remisiones</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.remisionesPorArea.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <p className="font-medium text-sm">{item.area}</p>
                    <p className="text-xs text-gray-600">{item.cantidad} remisiones activas</p>
                  </div>
                  <Badge
                    variant={
                      item.urgencia === "alta" ? "destructive" : item.urgencia === "media" ? "default" : "secondary"
                    }
                  >
                    {item.urgencia}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tendencia Mensual */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="h-5 w-5 mr-2" />
            Tendencia de Atenciones y Remisiones
          </CardTitle>
          <CardDescription>Evolución mensual de atenciones y remisiones</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex space-x-6 text-sm">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-blue-500 rounded mr-2"></div>
                <span>Atenciones</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-purple-500 rounded mr-2"></div>
                <span>Remisiones</span>
              </div>
            </div>
            <div className="grid grid-cols-5 gap-4">
              {data.tendenciaMensual.map((item, index) => (
                <div key={index} className="text-center">
                  <p className="text-xs text-gray-600 mb-2">{item.mes}</p>
                  <div className="space-y-1">
                    <div className="bg-gray-200 rounded-full overflow-hidden h-20 w-8 mx-auto">
                      <div
                        className="bg-blue-500 w-full rounded-full transition-all duration-500"
                        style={{ height: `${(item.atenciones / 50) * 100}%`, marginTop: "auto" }}
                      ></div>
                    </div>
                    <p className="text-xs font-medium">{item.atenciones}</p>
                  </div>
                  <div className="space-y-1 mt-2">
                    <div className="bg-gray-200 rounded-full overflow-hidden h-16 w-6 mx-auto">
                      <div
                        className="bg-purple-500 w-full rounded-full transition-all duration-500"
                        style={{ height: `${(item.remisiones / 25) * 100}%`, marginTop: "auto" }}
                      ></div>
                    </div>
                    <p className="text-xs font-medium">{item.remisiones}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Programas y Urgencias */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Programas con Más Atenciones */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BookOpen className="h-5 w-5 mr-2" />
              Programas con Más Atenciones
            </CardTitle>
            <CardDescription>Distribución por programa académico</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {data.programasConMasAtenciones.map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm font-medium">{item.programa}</span>
                      <span className="text-sm text-gray-600">{item.cantidad}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="h-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full transition-all duration-500"
                        style={{ width: `${item.porcentaje}%` }}
                      ></div>
                    </div>
                  </div>
                  <span className="text-xs text-gray-500 ml-3">{item.porcentaje}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Estadísticas de Urgencia */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="h-5 w-5 mr-2" />
              Niveles de Urgencia
            </CardTitle>
            <CardDescription>Distribución de urgencias en remisiones</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.estadisticasUrgencia.map((item, index) => (
                <div key={index} className="flex items-center space-x-4">
                  <div
                    className={`w-12 h-12 rounded-full ${item.color} flex items-center justify-center text-white font-bold`}
                  >
                    {item.cantidad}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{item.nivel}</p>
                    <p className="text-sm text-gray-600">
                      {(
                        (item.cantidad / data.estadisticasUrgencia.reduce((acc, curr) => acc + curr.cantidad, 0)) *
                        100
                      ).toFixed(1)}
                      % del total
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Acciones Rápidas */}
      <Card>
        <CardHeader>
          <CardTitle>Acciones Rápidas</CardTitle>
          <CardDescription>Accesos directos a funciones importantes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button variant="outline" className="h-20 flex-col">
              <FileText className="h-6 w-6 mb-2" />
              <span className="text-xs">Generar Reporte</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col">
              <Users className="h-6 w-6 mb-2" />
              <span className="text-xs">Ver Estudiantes</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col">
              <Send className="h-6 w-6 mb-2" />
              <span className="text-xs">Remisiones Pendientes</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col">
              <Clock className="h-6 w-6 mb-2" />
              <span className="text-xs">Seguimientos</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
